import { DOMAINS, DOMAIN_MAP, allTopics } from './domains'
import { GAPS, COVERED } from './gaps'
import { COMPARISONS } from './comparisons'
import { GRAPHS, PROJECTS, NOTES } from './content'
import type { DomainId, Topic } from './types'

export * from './types'
export { DOMAINS, DOMAIN_MAP, allTopics, GAPS, COVERED, COMPARISONS, GRAPHS, PROJECTS, NOTES }

export const TOPICS: Topic[] = allTopics()
export const TOPIC_MAP = new Map<string, Topic>(TOPICS.map((t) => [t.id, t]))

export function findTopic(id: string): Topic | undefined {
  return TOPIC_MAP.get(id)
}

export function domainName(id: DomainId): string {
  return DOMAIN_MAP.get(id)?.name ?? id
}

export const HERO_FLOW = [
  { label: 'Software Engineering', hint: 'craft & discipline' },
  { label: 'CS Fundamentals + Development + System Design', hint: 'the triple foundation' },
  { label: 'Databases', hint: 'persistence & internals' },
  { label: 'Cloud', hint: 'elastic substrate' },
  { label: 'DevOps', hint: 'ship & operate' },
  { label: 'Observability', hint: 'know, don’t guess' },
  { label: 'AI', hint: 'intelligence layer' },
  { label: 'MLOps', hint: 'models in production' },
  { label: 'Production', hint: 'where research lands' },
]

// Overall progress: weighted coverage + gap progress blend
export const OVERALL_PROGRESS = Math.round(
  DOMAINS.reduce((acc, d) => acc + d.coverage, 0) / DOMAINS.length
)

export const STATS = {
  topicsTotal: TOPICS.length,
  topicsCompleted: TOPICS.filter((t) => t.status === 'completed').length,
  topicsInProgress: TOPICS.filter((t) => t.status === 'in-progress').length,
  topicsNotStarted: TOPICS.filter((t) => t.status === 'not-started').length,
  gapsTotal: GAPS.length,
  coveredItems: COVERED.length,
  researchHours: 412,
  projectsCompleted: PROJECTS.filter((p) => p.phases.every((ph) => ph.status === 'completed')).length,
  projectsActive: PROJECTS.filter((p) => p.phases.some((ph) => ph.status === 'in-progress')).length,
}

export const RECOMMENDED_NEXT = [
  { title: 'Git internals: rebase, reflog, bisect', reason: 'Priority #01 · fastest compounding win', gapId: 'git-gap', minutes: 90 },
  { title: 'Linux namespaces & cgroups', reason: 'Priority #02 · unlocks container depth', gapId: 'linux-gap', minutes: 120 },
  { title: 'TCP/IP packet walkthrough', reason: 'Priority #03 · prerequisite for K8s networking', gapId: 'networks-gap', minutes: 75 },
  { title: 'Test pyramid retrofit on current codebase', reason: 'Priority #05 · protects existing work', gapId: 'testing-gap', minutes: 60 },
  { title: 'Kafka consumer-group semantics', reason: 'Priority #07 · active project blocker', gapId: 'message-queues-gap', minutes: 45 },
]

// Search index across topics + gaps + comparisons + projects
export interface SearchEntry {
  id: string
  kind: 'topic' | 'gap' | 'comparison' | 'project'
  name: string
  domain: string
  domainId?: DomainId
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced'
  status: string
  kindLabel: string
  prereqs: string[]
  related: string[]
  technologies: string[]
  summary: string
}

export const SEARCH_INDEX: SearchEntry[] = [
  ...TOPICS.map((t) => ({
    id: t.id,
    kind: 'topic' as const,
    name: t.name,
    domain: domainName(t.domain),
    domainId: t.domain,
    difficulty: t.difficulty,
    status: t.status,
    kindLabel: t.kind,
    prereqs: t.prereqs.map((p) => TOPIC_MAP.get(p)?.name ?? p),
    related: t.related.map((r) => TOPIC_MAP.get(r)?.name ?? r),
    technologies: [] as string[],
    summary: t.summary,
  })),
  ...GAPS.map((g) => ({
    id: g.id,
    kind: 'gap' as const,
    name: g.name,
    domain: domainName(g.domain),
    domainId: g.domain,
    difficulty: g.difficulty,
    status: g.status,
    kindLabel: `Research Gap · Priority ${String(g.rank).padStart(2, '0')}`,
    prereqs: g.prerequisites,
    related: g.relatedTopics.map((r) => TOPIC_MAP.get(r)?.name ?? r),
    technologies: g.technologies,
    summary: g.tagline,
  })),
  ...COMPARISONS.map((c) => ({
    id: c.id,
    kind: 'comparison' as const,
    name: c.title,
    domain: 'Comparison',
    difficulty: 'Intermediate' as const,
    status: 'reference',
    kindLabel: 'Technology Comparison',
    prereqs: [],
    related: [],
    technologies: c.options,
    summary: c.subtitle,
  })),
  ...PROJECTS.map((p) => ({
    id: p.id,
    kind: 'project' as const,
    name: p.title,
    domain: 'Project Lab',
    difficulty: p.difficulty,
    status: p.phases.some((ph) => ph.status === 'in-progress')
      ? 'in-progress'
      : p.phases.every((ph) => ph.status === 'completed')
        ? 'completed'
        : 'not-started',
    kindLabel: 'Lab Project',
    prereqs: p.relatedGaps.map((g) => GAPS.find((x) => x.id === g)?.name ?? g),
    related: [],
    technologies: p.stack,
    summary: p.concept,
  })),
]

export function searchPortal(query: string): SearchEntry[] {
  const q = query.trim().toLowerCase()
  if (!q) return []
  const tokens = q.split(/\s+/)
  return SEARCH_INDEX.map((e) => {
    const haystack = `${e.name} ${e.domain} ${e.kindLabel} ${e.summary} ${e.technologies.join(' ')} ${e.related.join(' ')}`.toLowerCase()
    let score = 0
    for (const tok of tokens) {
      if (e.name.toLowerCase().includes(tok)) score += 10
      if (e.technologies.some((t) => t.toLowerCase().includes(tok))) score += 6
      if (haystack.includes(tok)) score += 2
    }
    return { e, score }
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 24)
    .map((x) => x.e)
}
