export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced'
export type ResearchStatus = 'completed' | 'in-progress' | 'not-started'
export type TopicKind = 'Fundamentals' | 'Practical' | 'Production'

export type DomainId =
  | 'cs-fundamentals'
  | 'development'
  | 'system-design'
  | 'databases'
  | 'cloud'
  | 'devops'
  | 'observability'
  | 'data-engineering'
  | 'ai-ml'
  | 'mlops'
  | 'llm-engineering'

export interface Topic {
  id: string
  name: string
  domain: DomainId
  difficulty: Difficulty
  kind: TopicKind
  status: ResearchStatus
  prereqs: string[]
  related: string[]
  summary: string
}

export interface Domain {
  id: DomainId
  name: string
  short: string
  description: string
  coverage: number // 0-100
  color: string // tailwind-ish hex for charts/graphs
  icon: string // lucide icon name key
  topics: Topic[]
}

export interface ResearchGap {
  id: string
  rank: number
  name: string
  domain: DomainId
  tagline: string
  whyItMatters: string
  concepts: string[]
  technologies: string[]
  prerequisites: string[]
  relatedTopics: string[]
  researchQuestions: string[]
  suggestedProjects: string[]
  progress: number
  status: ResearchStatus
  estimatedScope: string
  notes: string
  difficulty: Difficulty
}

export interface ComparisonRow {
  dimension: string
  values: string[]
}

export interface TechComparison {
  id: string
  title: string
  subtitle: string
  options: string[]
  verdict: string
  rows: ComparisonRow[]
}

export interface GraphNode {
  id: string
  label: string
  status: ResearchStatus
}

export interface ResearchGraph {
  id: string
  title: string
  description: string
  nodes: GraphNode[]
  edges: [number, number][] // indices into nodes
}

export interface ProjectPhase {
  name: string
  status: ResearchStatus
  tasks: string[]
}

export interface LabProject {
  id: string
  title: string
  concept: string
  difficulty: Difficulty
  relatedGaps: string[]
  stack: string[]
  phases: ProjectPhase[]
  findings: string
}

export interface NoteItem {
  id: string
  title: string
  kind: 'note' | 'paper' | 'doc' | 'bookmark' | 'question' | 'experiment' | 'reference' | 'snippet'
  section: string
  excerpt: string
  tags: string[]
  updated: string
}

export const STATUS_LABEL: Record<ResearchStatus, string> = {
  completed: 'Completed',
  'in-progress': 'In Progress',
  'not-started': 'Not Started',
}
