'use client'

import { create } from 'zustand'
import type { DomainId } from './portal/types'

export type ViewId =
  | 'dashboard'
  | 'knowledge-map'
  | 'gaps'
  | 'explorer'
  | 'comparison'
  | 'graph'
  | 'roadmap'
  | 'notes'
  | 'progress'
  | 'projects'

interface PortalState {
  view: ViewId
  setView: (v: ViewId) => void

  topicPanelId: string | null // topic / gap / search-entry id opened in detail panel
  topicPanelKind: 'topic' | 'gap' | null
  openTopic: (id: string, kind?: 'topic' | 'gap') => void
  closeTopic: () => void

  copilotOpen: boolean
  setCopilotOpen: (open: boolean) => void

  mapDomain: DomainId | 'all'
  setMapDomain: (d: DomainId | 'all') => void

  explorerQuery: string
  setExplorerQuery: (q: string) => void

  savedTopics: string[]
  toggleSaved: (id: string) => void

  searchOpen: boolean
  setSearchOpen: (open: boolean) => void
}

export const usePortal = create<PortalState>((set, get) => ({
  view: 'dashboard',
  setView: (v) => set({ view: v }),

  topicPanelId: null,
  topicPanelKind: null,
  openTopic: (id, kind = 'topic') => set({ topicPanelId: id, topicPanelKind: kind }),
  closeTopic: () => set({ topicPanelId: null, topicPanelKind: null }),

  copilotOpen: false,
  setCopilotOpen: (open) => set({ copilotOpen: open }),

  mapDomain: 'all',
  setMapDomain: (d) => set({ mapDomain: d }),

  explorerQuery: '',
  setExplorerQuery: (q) => set({ explorerQuery: q }),

  savedTopics: ['message-queues-gap', 'rag', 'kafka'],
  toggleSaved: (id) => {
    const cur = get().savedTopics
    set({ savedTopics: cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id] })
  },

  searchOpen: false,
  setSearchOpen: (open) => set({ searchOpen: open }),
}))
