'use client'

import { AnimatePresence, motion } from 'framer-motion'
import { AppShell } from '@/components/portal/app-shell'
import { DashboardView } from '@/components/portal/dashboard'
import { KnowledgeMapView } from '@/components/portal/knowledge-map'
import { GapsView } from '@/components/portal/gaps-view'
import { ExplorerView } from '@/components/portal/explorer'
import { ComparisonView } from '@/components/portal/comparison'
import { GraphView } from '@/components/portal/graph-view'
import { RoadmapView } from '@/components/portal/roadmap-view'
import { NotesView } from '@/components/portal/notes-view'
import { ProgressView } from '@/components/portal/progress-view'
import { ProjectsView } from '@/components/portal/projects-view'
import { TopicPanel } from '@/components/portal/topic-panel'
import { CopilotPanel } from '@/components/portal/copilot'
import { usePortal } from '@/lib/store'

const VIEWS = {
  dashboard: DashboardView,
  'knowledge-map': KnowledgeMapView,
  gaps: GapsView,
  explorer: ExplorerView,
  comparison: ComparisonView,
  graph: GraphView,
  roadmap: RoadmapView,
  notes: NotesView,
  progress: ProgressView,
  projects: ProjectsView,
} as const

export default function Home() {
  const view = usePortal((s) => s.view)
  const ActiveView = VIEWS[view]

  return (
    <AppShell>
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-1 flex-col"
        >
          <ActiveView />
        </motion.div>
      </AnimatePresence>

      <footer className="mt-auto border-t">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-[11px] text-muted-foreground sm:flex-row md:px-8">
          <span>
            <span className="font-semibold text-foreground">Argus</span> — Research Intelligence Portal · built from the{' '}
            <span className="font-medium">Roadmap Gaps Review</span>
          </span>
          <span>Research + Engineering + Intelligence + Structure</span>
        </div>
      </footer>

      <TopicPanel />
      <CopilotPanel />
    </AppShell>
  )
}
