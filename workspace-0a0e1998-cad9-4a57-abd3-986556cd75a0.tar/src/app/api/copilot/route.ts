import { NextRequest } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { GAPS, TOPICS, COMPARISONS } from '@/lib/portal'

export const runtime = 'nodejs'
export const maxDuration = 60

const SYSTEM_PROMPT = `You are "Research Copilot", the AI research assistant inside Argus — an Engineering Research Operating System built from the user's "Roadmap Gaps Review".

The user is a strong full-stack/AI engineer (React, Next.js, Node, Java/Spring, Python/FastAPI, PostgreSQL, MongoDB, Redis, AWS/Azure/GCP, Docker, Kubernetes, ML, LLMs, RAG, LangChain/LangGraph, LanceDB) who has 12 identified research gaps:
01 Git/GitHub, 02 Linux, 03 Computer Networks, 04 Authentication & Security, 05 Testing, 06 System Design, 07 Message Queues, 08 Terraform + Helm, 09 Observability, 10 MLOps, 11 Data Engineering, 12 Software Architecture / Design Patterns.

Core thesis you must reinforce: the major issue is not adding more frameworks — it is building the foundational and production-engineering layer that connects technologies together.

Style rules:
- Be concise, structured, and technical. Prefer short paragraphs, tight bullets, and concrete examples.
- When explaining concepts: define → mental model → why it matters for THIS user's gaps → a small practical next step.
- When comparing technologies: give a balanced, factual comparison and a verdict tied to their stack.
- When building learning paths: order by dependencies, reference the priority ranks above, estimate scope in weeks.
- Never invent certifications or courses; stay in the vocabulary of the roadmap (domains: CS Fundamentals, Development, System Design, Databases, Cloud, DevOps, Observability, Data Engineering, AI/ML, MLOps, LLM Engineering).
- Maximum ~350 words unless the user explicitly asks for depth.`

function localFallback(message: string): string {
  const q = message.toLowerCase()

  if (q.includes('cap')) {
    return `**CAP theorem, simply:** in a distributed system, when a network partition (P) happens, you must choose between consistency (C) and availability (A). You can't have all three guarantees at once — and partitions are not optional, they will happen.

**Mental model:** think of two data centers cut off from each other. Either both keep accepting writes (available, but now inconsistent) or one refuses writes (consistent, but unavailable).

**Why it matters for your roadmap:** it's the theory behind your rank-06 System Design gap — replication (PostgreSQL) and sharding choices are CP-vs-AP decisions in disguise.

**Next step:** one 45-minute session — map your current Postgres replication setup onto the CAP axis, then read how Kafka's acks=all leans CP.`
  }
  if (q.includes('kafka') && (q.includes('rabbit') || q.includes('compare'))) {
    const c = COMPARISONS.find((x) => x.id === 'kafka-vs-rabbitmq')
    return `**Kafka vs RabbitMQ (short version):**\n\n- **Model:** Kafka is a distributed append-only log (consumers track offsets); RabbitMQ is an AMQP queue broker (per-message routing + acks).\n- **Throughput:** Kafka wins at streaming scale (sequential I/O, millions msg/s); RabbitMQ is comfortable at task-queue scale.\n- **Replay:** Kafka retains events, so consumers can rewind; RabbitMQ removes messages once acked.\n- **Routing:** RabbitMQ's exchanges/bindings beat Kafka for fine-grained routing.\n\n**Verdict for your roadmap (rank 07):** learn Kafka first — it feeds directly into Data Engineering (rank 11). Add Redis Streams (already in your stack) for lightweight cases.\n\n**Next step:** the order-events docker-compose drill from the Project Lab.`
  }
  if (q.includes('mlops') && (q.includes('path') || q.includes('learn') || q.includes('roadmap'))) {
    return `**Learning path for MLOps (rank 10), dependency-ordered:**\n\n1. **Week 1 — MLflow tracking:** log params/metrics/artifacts from an existing training script. Prereq: ML (covered).\n2. **Week 2 — Registry + versioning:** model registry stages, dataset versioning with DVC.\n3. **Week 3 — Deployment:** package a model as a Docker image, serve behind FastAPI, canary on Kubernetes (covered).\n4. **Week 4 — Monitoring:** drift detection with Evidently; reuse the Prometheus/Grafana stack from rank 09.\n\n**Why this order:** each layer reuses the previous one — observability (rank 09) and IaC (rank 08) are force multipliers here, which is exactly why the review sequenced them first.\n\n**Exit criterion:** one model, notebook → production, with rollback demonstrated.`
  }
  if (q.includes('kubernetes') && (q.includes('before') || q.includes('prereq'))) {
    return `**Before Kubernetes, shore up these prerequisites:**\n\n1. **Linux (rank 02)** — namespaces, cgroups, systemd. K8s is Linux abstractions all the way down.\n2. **Networking (rank 03)** — DNS, TCP/IP, TLS. Service discovery and CNI plugins assume it.\n3. **Docker** — you have this covered; deepen with multi-stage builds and image layers.\n4. **Git (rank 01)** — GitOps flows (ArgoCD) require confident branching/reverting.\n\n**Why:** the review's thesis — K8s without Linux+networking is incantation. You already run it; the goal is understanding it.\n\n**Next step:** the "minimal container runtime" experiment in bash (unshare + chroot) — one evening, huge payoff.`
  }
  if (q.includes('gap') && (q.includes('system') || q.includes('design'))) {
    return `**System-design knowledge gaps (rank 06), ranked by impact:**\n\n1. **Caching strategy** — invalidation, stampede protection (you already run Redis).\n2. **Consistency models** — CAP, isolation levels; connects Databases to Distributed Systems.\n3. **Load balancing & ingress** — pairs with rank 03 networking.\n4. **Event-driven architecture** — feeds rank 07 message queues.\n\n**Approach the review recommends:** one written design doc per week — "scale my app from 100 to 10M users" style — then critique it against production realities.\n\n**Next step:** diagram your current production topology and mark every single point of failure.`
  }
  return `Here's how I'd frame that within your roadmap:\n\n- **Connect it to a gap:** this maps most directly onto the foundational/production layer the review prioritizes — start from the related rank in Research Gaps.\n- **Mental model:** define the concept, then find the smallest system where it visibly matters.\n- **Practical step:** 45–90 minutes — one experiment in the Project Lab or one written design note.\n\nAsk me to "explain", "compare", or "build a learning path" for any topic — e.g. "Explain CAP theorem simply", "Compare Kafka and RabbitMQ", "Build a learning path for MLOps".`
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { messages?: { role: string; content: string }[] }
    const messages = body.messages ?? []
    const lastUser = [...messages].reverse().find((m) => m.role === 'user')

    const context = `Relevant corpus entries: ${TOPICS.slice(0, 8)
      .map((t) => t.name)
      .join(', ')}…; gaps: ${GAPS.map((g) => `${String(g.rank).padStart(2, '0')}-${g.name}`).join(', ')}.`

    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'system', content: context },
        ...messages.slice(-8).map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
      ] as never,
    })

    const reply =
      (completion as unknown as { choices?: { message?: { content?: string } }[] })?.choices?.[0]?.message?.content ??
      localFallback(lastUser?.content ?? '')

    return Response.json({ reply, source: 'model' })
  } catch (err) {
    console.error('[copilot] falling back to local responder:', err)
    const body = await req.json().catch(() => ({ messages: [] }))
    const lastUser = (body.messages ?? []).reverse().find((m) => m.role === 'user')
    return Response.json({ reply: localFallback(lastUser?.content ?? ''), source: 'local' })
  }
}
