'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, CheckCircle2, Circle, CircleDot, Quote } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { PROJECTS } from '@/lib/portal'
import { SectionHeading, DifficultyTag, StatusBadge } from './atoms'
import type { ResearchStatus } from '@/lib/portal/types'

const PHASES = ['Concept', 'Architecture', 'Implementation', 'Testing', 'Observability', 'Deployment', 'Research Findings']

const PHASE_ICON: Record<ResearchStatus, typeof Circle> = {
  completed: CheckCircle2,
  'in-progress': CircleDot,
  'not-started': Circle,
}

const PHASE_CLS: Record<ResearchStatus, string> = {
  completed: 'text-emerald-500',
  'in-progress': 'text-amber-500',
  'not-started': 'text-muted-foreground/40',
}

function projectProgress(p: (typeof PROJECTS)[number]) {
  const done = p.phases.filter((ph) => ph.status === 'completed').length
  return Math.round((done / p.phases.length) * 100)
}

export function ProjectsView() {
  const [expanded, setExpanded] = useState<string | null>(PROJECTS[0].id)

  const counts = useMemo(
    () => ({
      active: PROJECTS.filter((p) => p.phases.some((ph) => ph.status === 'in-progress')).length,
      done: PROJECTS.filter((p) => p.phases.every((ph) => ph.status === 'completed')).length,
    }),
    []
  )

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Project / Experiment Lab"
        title="Where research becomes running systems"
        sub="Each project walks the full engineering arc: Concept → Architecture → Implementation → Testing → Observability → Deployment → Research Findings."
      />

      <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
        <Badge variant="secondary">{counts.active} active</Badge>
        <Badge variant="secondary">{counts.done} completed</Badge>
        <Badge variant="secondary">{PROJECTS.length} total experiments</Badge>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {PROJECTS.map((p, i) => {
          const open = expanded === p.id
          const pct = projectProgress(p)
          return (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: Math.min(i * 0.05, 0.3), ease: [0.22, 1, 0.36, 1] }}
              className={cn(open && 'lg:col-span-2')}
            >
              <Card className={cn('h-full overflow-hidden transition-all duration-300 hover:border-primary/30 hover:shadow-md', open && 'border-primary/40')}>
                <CardContent className="p-5">
                  <button className="w-full text-left" onClick={() => setExpanded(open ? null : p.id)} aria-expanded={open}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="text-[15px] font-semibold tracking-tight transition-colors hover:text-primary">{p.title}</h3>
                        <p className="mt-0.5 text-xs text-muted-foreground">{p.concept}</p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1.5">
                        <DifficultyTag level={p.difficulty} />
                        <span className="text-[11px] font-semibold tabular-nums text-muted-foreground">{pct}%</span>
                      </div>
                    </div>

                    {/* phase rail */}
                    <div className="mt-4 flex items-center gap-1 overflow-x-auto pb-1 scrollbar-slim">
                      {PHASES.map((ph, idx) => {
                        const found = p.phases.find((x) => x.name === ph)
                        const status: ResearchStatus = found?.status ?? 'not-started'
                        const Icon = PHASE_ICON[status]
                        return (
                          <div key={ph} className="flex items-center gap-1">
                            <div
                              className={cn(
                                'flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10.5px] font-medium transition-all duration-300',
                                status === 'completed' && 'border-emerald-500/30 bg-emerald-500/[0.07] text-emerald-700 dark:text-emerald-400',
                                status === 'in-progress' && 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400',
                                status === 'not-started' && 'text-muted-foreground/70'
                              )}
                            >
                              <Icon className={cn('h-3 w-3', PHASE_CLS[status])} />
                              {ph}
                            </div>
                            {idx < PHASES.length - 1 && <ArrowDown className="hidden h-3 w-3 -rotate-90 text-border" />}
                          </div>
                        )
                      })}
                    </div>

                    <div className="mt-3 flex flex-wrap gap-1">
                      {p.stack.map((s) => (
                        <span key={s} className="rounded border bg-secondary/40 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                          {s}
                        </span>
                      ))}
                    </div>
                  </button>

                  {open && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 grid gap-2 border-t pt-4 sm:grid-cols-2">
                        {p.phases.map((ph) => {
                          const Icon = PHASE_ICON[ph.status]
                          return (
                            <div key={ph.name} className="rounded-xl border bg-secondary/30 p-3.5">
                              <div className="flex items-center gap-2 pb-1.5">
                                <Icon className={cn('h-3.5 w-3.5', PHASE_CLS[ph.status])} />
                                <span className="text-[12.5px] font-semibold">{ph.name}</span>
                                <StatusBadge status={ph.status} className="ml-auto scale-90" />
                              </div>
                              <ul className="space-y-1">
                                {ph.tasks.map((t) => (
                                  <li key={t} className="flex items-start gap-1.5 text-[11.5px] text-muted-foreground">
                                    <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-current opacity-50" />
                                    {t}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )
                        })}
                      </div>

                      <div className="quote-mark mt-4 rounded-xl border bg-card p-4 pl-9">
                        <div className="mb-1 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
                          <Quote className="h-3 w-3" /> Research findings
                        </div>
                        <p className="text-[13px] leading-relaxed text-muted-foreground">{p.findings}</p>
                      </div>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
