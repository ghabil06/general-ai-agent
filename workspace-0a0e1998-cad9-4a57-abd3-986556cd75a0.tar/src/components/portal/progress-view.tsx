'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import {
  RadialBarChart,
  RadialBar,
  PolarAngleAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip as RTooltip,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Area,
  AreaChart,
} from 'recharts'
import { Card, CardContent } from '@/components/ui/card'
import { Clock3, CheckCircle2, GitBranch, Layers, FolderKanban } from 'lucide-react'
import { usePortal } from '@/lib/store'
import { DOMAINS, GAPS, STATS } from '@/lib/portal'
import { ProgressBar, SectionHeading, StatusBadge } from './atoms'

const tooltipStyle = {
  backgroundColor: 'var(--popover)',
  border: '1px solid var(--border)',
  borderRadius: 10,
  fontSize: 12,
  color: 'var(--popover-foreground)',
}

function Ring({ value, label, color = 'var(--chart-1)', size = 116 }: { value: number; label: string; color?: string; size?: number }) {
  const [shown, setShown] = useState(0)
  useEffect(() => {
    const t = setTimeout(() => setShown(value), 150)
    return () => clearTimeout(t)
  }, [value])
  const data = [{ name: label, value: shown, fill: color }]
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <ResponsiveContainer width="100%" height="100%">
        <RadialBarChart innerRadius="72%" outerRadius="100%" data={data} startAngle={90} endAngle={-270}>
          <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
          <RadialBar background={{ fill: 'var(--muted)' }} dataKey="value" cornerRadius={size / 2} />
        </RadialBarChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="text-lg font-semibold tabular-nums">{value}%</div>
          <div className="text-[9.5px] uppercase tracking-[0.1em] text-muted-foreground">{label}</div>
        </div>
      </div>
    </div>
  )
}

const WEEKLY = [
  { week: 'W1', hours: 6.5 },
  { week: 'W2', hours: 9 },
  { week: 'W3', hours: 7.5 },
  { week: 'W4', hours: 11 },
  { week: 'W5', hours: 8.5 },
  { week: 'W6', hours: 12 },
  { week: 'W7', hours: 10.5 },
  { week: 'W8', hours: 13 },
]

const DEP_DATA = [
  { stage: 'Foundations', value: 74 },
  { stage: 'Platforms', value: 52 },
  { stage: 'Data', value: 38 },
  { stage: 'Intelligence', value: 66 },
  { stage: 'Production', value: 24 },
]

export function ProgressView() {
  const { setView, openTopic } = usePortal()
  const gapStatus = {
    completed: GAPS.filter((g) => g.status === 'completed').length,
    inProgress: GAPS.filter((g) => g.status === 'in-progress').length,
    notStarted: GAPS.filter((g) => g.status === 'not-started').length,
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Progress Dashboard"
        title="Research analytics"
        sub="Coverage, gaps, throughput, and dependency health — measured, not vibes."
      />

      {/* KPI row */}
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { icon: Clock3, label: 'Research Hours', value: STATS.researchHours, sub: '+13h this week' },
          { icon: CheckCircle2, label: 'Topics Completed', value: STATS.topicsCompleted, sub: `of ${STATS.topicsTotal} topics` },
          { icon: Layers, label: 'Research Gaps', value: STATS.gapsTotal, sub: `${gapStatus.inProgress} active` },
          { icon: FolderKanban, label: 'Projects', value: STATS.projectsCompleted + STATS.projectsActive, sub: `${STATS.projectsActive} in flight` },
        ].map((k, i) => (
          <motion.div
            key={k.label}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.4 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 pb-2 text-muted-foreground">
                  <k.icon className="h-3.5 w-3.5" />
                  <span className="text-[11px] font-medium">{k.label}</span>
                </div>
                <div className="text-2xl font-semibold tabular-nums tracking-tight">{k.value}</div>
                <div className="pt-0.5 text-[11px] text-muted-foreground">{k.sub}</div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        {/* Domain coverage */}
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <div className="flex items-center justify-between pb-4">
              <div className="text-[13px] font-semibold">Domain Coverage</div>
              <button className="text-[11px] text-primary hover:underline" onClick={() => setView('knowledge-map')}>
                open knowledge map →
              </button>
            </div>
            <div className="space-y-3">
              {[...DOMAINS].sort((a, b) => b.coverage - a.coverage).map((d, i) => (
                <button
                  key={d.id}
                  onClick={() => setView('knowledge-map')}
                  className="group w-full text-left"
                >
                  <div className="flex items-center justify-between pb-1 text-xs">
                    <span className="font-medium transition-colors group-hover:text-primary">{d.name}</span>
                    <span className="tabular-nums text-muted-foreground">{d.coverage}%</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="progress-fill h-full rounded-full"
                      style={{ width: `${d.coverage}%`, background: d.color, transitionDelay: `${i * 50}ms` }}
                    />
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-5 grid grid-cols-3 gap-2 border-t pt-4 text-center">
              <div>
                <div className="text-sm font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">{STATS.topicsCompleted}</div>
                <div className="text-[10px] text-muted-foreground">completed</div>
              </div>
              <div>
                <div className="text-sm font-semibold tabular-nums text-amber-600 dark:text-amber-400">{STATS.topicsInProgress}</div>
                <div className="text-[10px] text-muted-foreground">in progress</div>
              </div>
              <div>
                <div className="text-sm font-semibold tabular-nums text-muted-foreground">{STATS.topicsNotStarted}</div>
                <div className="text-[10px] text-muted-foreground">not started</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Rings */}
        <Card>
          <CardContent className="flex h-full flex-col items-center justify-center gap-2 p-5">
            <div className="self-start pb-1 text-[13px] font-semibold">Gap Status</div>
            <div className="flex items-center justify-center gap-1 py-2">
              <Ring value={Math.round((gapStatus.inProgress / GAPS.length) * 100)} label="active" color="var(--chart-2)" size={104} />
              <Ring value={Math.round(((STATS.topicsCompleted) / STATS.topicsTotal) * 100)} label="topics" color="var(--chart-1)" size={104} />
            </div>
            <div className="w-full space-y-2 pt-2">
              {[
                { s: 'in-progress' as const, n: gapStatus.inProgress },
                { s: 'not-started' as const, n: gapStatus.notStarted },
              ].map(({ s, n }) => (
                <div key={s} className="flex items-center justify-between rounded-lg border bg-secondary/40 px-3 py-2 text-xs">
                  <StatusBadge status={s} />
                  <span className="font-semibold tabular-nums">{n} gaps</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Weekly hours */}
        <Card className="lg:col-span-2">
          <CardContent className="p-5">
            <div className="pb-4 text-[13px] font-semibold">Research Timeline — hours per week</div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={WEEKLY} margin={{ top: 6, right: 6, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="hoursFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.28} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="week" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <RTooltip contentStyle={tooltipStyle} cursor={{ stroke: 'var(--border)' }} />
                  <Area type="monotone" dataKey="hours" stroke="var(--chart-1)" strokeWidth={2} fill="url(#hoursFill)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Knowledge gap chart */}
        <Card>
          <CardContent className="p-5">
            <div className="pb-4 text-[13px] font-semibold">Knowledge-Gap Chart</div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={DEP_DATA} layout="vertical" margin={{ top: 0, right: 12, left: 6, bottom: 0 }}>
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis
                    type="category"
                    dataKey="stage"
                    width={78}
                    tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <RTooltip contentStyle={tooltipStyle} cursor={{ fill: 'var(--secondary)' }} />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={14}>
                    {DEP_DATA.map((entry, i) => (
                      <Cell key={i} fill={i === 4 ? 'var(--chart-3)' : i === 2 ? 'var(--chart-2)' : 'var(--chart-1)'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <p className="pt-2 text-[11px] leading-relaxed text-muted-foreground">
              Concept dependency health by roadmap layer — Production is the thinnest link, matching the review’s thesis.
            </p>
          </CardContent>
        </Card>

        {/* Concept dependencies */}
        <Card className="lg:col-span-3">
          <CardContent className="p-5">
            <div className="flex items-center justify-between pb-3">
              <div className="flex items-center gap-2 text-[13px] font-semibold">
                <GitBranch className="h-3.5 w-3.5 text-primary" /> Concept Dependencies
              </div>
              <button className="text-[11px] text-primary hover:underline" onClick={() => setView('graph')}>
                open research graph →
              </button>
            </div>
            <div className="grid gap-2 sm:grid-cols-3">
              {[
                { chain: 'Linux → Networking → Docker → Kubernetes', pct: 55 },
                { chain: 'SQL → Indexes → Optimization → ACID → Sharding', pct: 42 },
                { chain: 'ML → MLflow → Registry → Deployment → Monitoring', pct: 30 },
              ].map((c) => (
                <button
                  key={c.chain}
                  onClick={() => setView('graph')}
                  className="rounded-xl border bg-secondary/30 p-3.5 text-left transition-all duration-300 hover:border-primary/35 hover:bg-secondary/50"
                >
                  <div className="pb-2 font-mono text-[11px] text-muted-foreground">{c.chain}</div>
                  <ProgressBar value={c.pct} />
                  <div className="pt-1.5 text-[10px] tabular-nums text-muted-foreground">{c.pct}% of chain covered</div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
