'use client'

import { useEffect, useMemo, useState } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  BookOpen,
  Boxes,
  Check,
  ChevronRight,
  CircleAlert,
  Cog,
  FlaskConical,
  HelpCircle,
  Layers,
  Lightbulb,
  ListChecks,
  Plus,
  Save,
  Star,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import {
  GAPS,
  TOPIC_MAP,
  findTopic,
  domainName,
  type ResearchGap,
  type Topic,
} from '@/lib/portal'
import { StatusBadge, DifficultyTag, ProgressBar } from './atoms'

/* ── Architecture diagrams ─────────────────────────────── */

function MessageFlowDiagram() {
  const stages = ['Producer', 'Message Broker', 'Consumer']
  const [pulse, setPulse] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setPulse((p) => (p + 1) % 3), 1400)
    return () => clearInterval(t)
  }, [])
  return (
    <div className="flex items-center justify-center gap-2 rounded-xl border bg-secondary/40 p-4 sm:gap-3 sm:p-5" role="img" aria-label="Producer to message broker to consumer flow">
      {stages.map((s, i) => (
        <div key={s} className="flex items-center gap-2 sm:gap-3">
          <div
            className={cn(
              'rounded-lg border bg-card px-3 py-2.5 text-center transition-all duration-500 sm:px-5 sm:py-3',
              pulse === i ? 'node-glow border-primary/50' : ''
            )}
          >
            <div className="text-[13px] font-medium">{s}</div>
            <div className="text-[10px] text-muted-foreground">
              {i === 0 ? 'emit events' : i === 1 ? 'Kafka · RabbitMQ' : 'process & ack'}
            </div>
          </div>
          {i < 2 && (
            <svg viewBox="0 0 40 12" className="h-3 w-8 shrink-0 text-primary sm:w-12" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M0 6h32" strokeLinecap="round" />
              <path d="M28 2l6 4-6 4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
      ))}
    </div>
  )
}

function GenericArchitecture({ name }: { name: string }) {
  const layers = ['Client / Producer', `${name} core`, 'Storage & state', 'Consumers / downstream']
  return (
    <div className="space-y-1.5 rounded-xl border bg-secondary/40 p-4">
      {layers.map((l, i) => (
        <div key={l} className="flex items-center gap-3">
          <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-primary/10 font-mono text-[10px] font-semibold text-primary">
            {i + 1}
          </span>
          <div className="flex-1 rounded-lg border bg-card px-3 py-2 text-[13px]">{l}</div>
        </div>
      ))}
    </div>
  )
}

/* ── Small building blocks ─────────────────────────────── */

function Block({
  icon: Icon,
  title,
  children,
}: {
  icon: typeof BookOpen
  title: string
  children: React.ReactNode
}) {
  return (
    <section className="space-y-2.5">
      <h4 className="flex items-center gap-2 text-[13px] font-semibold tracking-tight">
        <Icon className="h-3.5 w-3.5 text-primary" />
        {title}
      </h4>
      {children}
    </section>
  )
}

function ChipList({ items, onClickItem }: { items: string[]; onClickItem?: (name: string) => void }) {
  if (!items.length) return <p className="text-xs text-muted-foreground">None recorded — this is a starting point.</p>
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((it) => (
        <button
          key={it}
          disabled={!onClickItem}
          onClick={() => onClickItem?.(it)}
          className={cn(
            'rounded-md border bg-secondary/50 px-2 py-1 text-xs transition-colors duration-200',
            onClickItem && 'hover:border-primary/40 hover:bg-primary/10 hover:text-primary'
          )}
        >
          {it}
        </button>
      ))}
    </div>
  )
}

function findTopicByName(name: string): Topic | undefined {
  const lower = name.toLowerCase()
  return [...TOPIC_MAP.values()].find(
    (t) => t.name.toLowerCase() === lower || t.name.toLowerCase().includes(lower)
  )
}

/* ── The panel ─────────────────────────────────────────── */

export function TopicPanel() {
  const { topicPanelId, topicPanelKind, closeTopic, savedTopics, toggleSaved, openTopic } = usePortal()
  const [savedFlashId, setSavedFlashId] = useState<string | null>(null)

  const gap = useMemo(
    () => (topicPanelKind === 'gap' ? GAPS.find((g) => g.id === topicPanelId) : undefined),
    [topicPanelId, topicPanelKind]
  )
  const topic = useMemo(
    () => (topicPanelKind === 'topic' ? findTopic(topicPanelId ?? '') : undefined),
    [topicPanelId, topicPanelKind]
  )

  const open = Boolean(gap || topic)
  const title = gap?.name ?? topic?.name ?? ''
  const isGap = Boolean(gap)
  const saved = savedTopics.includes(topicPanelId ?? '')
  const confirmSaved = savedFlashId !== null && savedFlashId === topicPanelId

  const handleSave = () => {
    if (!topicPanelId) return
    toggleSaved(topicPanelId)
    setSavedFlashId(topicPanelId)
    setTimeout(() => setSavedFlashId((cur) => (cur === topicPanelId ? null : cur)), 1800)
  }

  const architecture =
    gap?.id === 'message-queues-gap' ? (
      <MessageFlowDiagram />
    ) : (
      <GenericArchitecture name={title || 'System'} />
    )

  return (
    <Sheet open={open} onOpenChange={(o) => !o && closeTopic()}>
      <SheetContent side="right" className="w-full max-w-2xl overflow-y-auto p-0 sm:max-w-2xl scrollbar-slim">
        {gap || topic ? (
          <>
            <div className="sticky top-0 z-10 border-b bg-background/90 px-6 py-4 backdrop-blur-md">
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 pb-1.5 text-[11px] font-medium text-muted-foreground">
                    {gap ? (
                      <Badge className="bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/25 hover:bg-amber-500/10" variant="outline">
                        Priority {String(gap.rank).padStart(2, '0')} Research Gap
                      </Badge>
                    ) : (
                      <Badge variant="outline">{domainName(topic!.domain)}</Badge>
                    )}
                    <span>{isGap ? gap!.domain && domainName(gap!.domain) : topic!.kind}</span>
                  </div>
                  <SheetTitle className="text-lg leading-snug tracking-tight">{title}</SheetTitle>
                  {gap && <p className="pt-1 text-[13px] text-muted-foreground">{gap.tagline}</p>}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Button
                    size="sm"
                    variant={saved ? 'secondary' : 'outline'}
                    onClick={handleSave}
                    className={cn('gap-1.5 overflow-hidden transition-all duration-300', confirmSaved && 'border-emerald-500/50 text-emerald-600 dark:text-emerald-400')}
                  >
                    {confirmSaved ? (
                      <>
                        <Check className="h-3.5 w-3.5" /> Saved
                      </>
                    ) : (
                      <>
                        <Save className="h-3.5 w-3.5" /> {saved ? 'Saved' : 'Save'}
                      </>
                    )}
                  </Button>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <StatusBadge status={(gap?.status ?? topic!.status) as never} />
                <DifficultyTag level={(gap?.difficulty ?? topic!.difficulty) as never} />
                {gap && (
                  <div className="flex min-w-40 flex-1 items-center gap-2.5">
                    <ProgressBar value={gap.progress} className="h-1" />
                    <span className="text-[11px] tabular-nums text-muted-foreground">{gap.progress}%</span>
                  </div>
                )}
              </div>
            </div>

            <Tabs defaultValue="overview" className="px-6 pb-10 pt-4">
              <TabsList className="mb-4 h-8 w-full justify-start overflow-x-auto rounded-lg bg-secondary/60 p-0.5 scrollbar-slim">
                <TabsTrigger value="overview" className="h-7 rounded-md text-xs">Overview</TabsTrigger>
                <TabsTrigger value="concepts" className="h-7 rounded-md text-xs">Concepts</TabsTrigger>
                <TabsTrigger value="research" className="h-7 rounded-md text-xs">Research</TabsTrigger>
                <TabsTrigger value="build" className="h-7 rounded-md text-xs">Build</TabsTrigger>
              </TabsList>

              {/* ── Overview ── */}
              <TabsContent value="overview" className="mt-0 space-y-6">
                <Block icon={BookOpen} title="Overview">
                  <p className="text-[13.5px] leading-relaxed text-muted-foreground">
                    {gap?.whyItMatters ?? topic!.summary}
                  </p>
                </Block>

                {gap && (
                  <Block icon={Layers} title="Architecture">
                    {architecture}
                  </Block>
                )}

                <Block icon={Boxes} title="Technologies">
                  <ChipList
                    items={gap?.technologies ?? []}
                    onClickItem={(n) => {
                      const t = findTopicByName(n)
                      if (t) openTopic(t.id, 'topic')
                    }}
                  />
                  {!gap && (
                    <p className="text-xs text-muted-foreground">
                      Technology detail lives in the domain map — related topics below carry the stack context.
                    </p>
                  )}
                </Block>

                <Block icon={ListChecks} title="Prerequisites">
                  <ChipList
                    items={gap?.prerequisites ?? topic!.prereqs.map((p) => TOPIC_MAP.get(p)?.name ?? p)}
                    onClickItem={(n) => {
                      const t = findTopicByName(n)
                      if (t) openTopic(t.id, 'topic')
                    }}
                  />
                </Block>

                <Block icon={ChevronRight} title="Related Topics">
                  <ChipList
                    items={gap?.relatedTopics.map((r) => TOPIC_MAP.get(r)?.name ?? r) ?? topic!.related.map((r) => TOPIC_MAP.get(r)?.name ?? r)}
                    onClickItem={(n) => {
                      const t = findTopicByName(n)
                      if (t) openTopic(t.id, 'topic')
                    }}
                  />
                </Block>
              </TabsContent>

              {/* ── Concepts ── */}
              <TabsContent value="concepts" className="mt-0 space-y-6">
                <Block icon={Layers} title="Concepts to Learn">
                  {gap ? (
                    <ol className="space-y-2">
                      {gap.concepts.map((c, i) => (
                        <li key={c} className="flex items-start gap-3 rounded-lg border bg-card px-3 py-2.5">
                          <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded bg-primary/10 font-mono text-[10px] font-semibold text-primary">
                            {String(i + 1).padStart(2, '0')}
                          </span>
                          <span className="text-[13px]">{c}</span>
                        </li>
                      ))}
                    </ol>
                  ) : (
                    <p className="text-[13px] leading-relaxed text-muted-foreground">{topic!.summary}</p>
                  )}
                </Block>
                <Block icon={Cog} title="Production Considerations">
                  <ul className="space-y-1.5 text-[13px] text-muted-foreground">
                    {(gap
                      ? [
                          'Instrument before scaling — measure the baseline first',
                          'Design failure behavior deliberately: retries, DLQs, rollbacks',
                          'Document operational runbooks as part of the research output',
                        ]
                      : [
                          'Validate assumptions under production load, not synthetic tests',
                          'Keep blast radius small: feature flags, canaries, reversible changes',
                          'Record decisions (ADRs) so future-you understands the why',
                        ]
                    ).map((x) => (
                      <li key={x} className="flex items-start gap-2">
                        <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary/70" />
                        {x}
                      </li>
                    ))}
                  </ul>
                </Block>
              </TabsContent>

              {/* ── Research ── */}
              <TabsContent value="research" className="mt-0 space-y-6">
                <Block icon={HelpCircle} title="Research Questions">
                  <div className="space-y-2">
                    {(gap?.researchQuestions ?? [
                      `What are the failure modes of ${title} under real production traffic?`,
                      `Which adjacent topics change how ${title} should be applied?`,
                      `What would a minimal experiment proving the core trade-off look like?`,
                    ]).map((rq, i) => (
                      <div
                        key={i}
                        className="quote-mark group rounded-lg border bg-card p-3.5 pl-6 text-[13px] leading-relaxed transition-all duration-300 hover:border-primary/30 hover:shadow-sm"
                      >
                        {rq}
                      </div>
                    ))}
                  </div>
                </Block>
                {gap && (
                  <Block icon={FlaskConical} title="Estimated Research Scope">
                    <div className="rounded-lg border bg-secondary/40 px-3.5 py-2.5 text-[13px]">
                      {gap.estimatedScope}
                    </div>
                    <p className="text-xs leading-relaxed text-muted-foreground">{gap.notes}</p>
                  </Block>
                )}
              </TabsContent>

              {/* ── Build ── */}
              <TabsContent value="build" className="mt-0 space-y-6">
                <Block icon={Lightbulb} title="Implementation Ideas / Suggested Projects">
                  <div className="grid gap-2">
                    {(gap?.suggestedProjects ?? [
                      `Prototype ${title} in the existing stack end-to-end`,
                      'Write a benchmark or eval harness that measures the core trade-off',
                      'Document findings as an ADR + blog-grade research note',
                    ]).map((p) => (
                      <div key={p} className="flex items-start gap-2.5 rounded-lg border bg-card px-3.5 py-3">
                        <Plus className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                        <span className="text-[13px]">{p}</span>
                      </div>
                    ))}
                  </div>
                </Block>
                <Block icon={Star} title="Progress Tracker">
                  <div className="rounded-xl border bg-card p-4">
                    <div className="flex items-center justify-between pb-2 text-[13px]">
                      <span className="font-medium">{title}</span>
                      <span className="tabular-nums text-muted-foreground">
                        {gap ? gap.progress : topic!.status === 'completed' ? 100 : topic!.status === 'in-progress' ? 50 : 0}%
                      </span>
                    </div>
                    <ProgressBar
                      value={gap ? gap.progress : topic!.status === 'completed' ? 100 : topic!.status === 'in-progress' ? 50 : 0}
                    />
                    <p className="pt-2.5 text-xs text-muted-foreground">
                      Track milestones in Notes → Experiments. Each completed research question can be linked from the
                      progress log.
                    </p>
                  </div>
                </Block>
              </TabsContent>
            </Tabs>

            <Separator />
            <div className="px-6 py-4 text-[11px] text-muted-foreground">
              Source: <span className="font-medium">Roadmap Gaps Review</span> — content preserved from the reference
              review and structured for research use.
            </div>
          </>
        ) : null}
      </SheetContent>
    </Sheet>
  )
}
