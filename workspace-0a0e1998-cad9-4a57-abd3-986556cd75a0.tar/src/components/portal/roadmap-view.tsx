'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, BookMarked, Clock3, Flag } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { GAPS } from '@/lib/portal'
import { ProgressBar, SectionHeading, StatusBadge, DifficultyTag } from './atoms'

export function RoadmapView() {
  const { openTopic, setView } = usePortal()
  const ordered = useMemo(() => [...GAPS].sort((a, b) => a.rank - b.rank), [])
  const [justStarted, setJustStarted] = useState<string | null>(null)

  const handleStart = (id: string) => {
    setJustStarted(id)
    setTimeout(() => setJustStarted(null), 1800)
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Research Roadmap"
        title="Twelve priorities, in research order"
        sub="Not a course curriculum — a structured engineering research sequence. Each item carries prerequisites, scope, and a practical experiment. Ranks compound: later layers reuse earlier ones."
      />

      {/* Timeline */}
      <div className="relative mt-10">
        <div className="absolute bottom-0 left-[19px] top-2 w-px bg-gradient-to-b from-primary/50 via-border to-transparent md:left-1/2" />

        <div className="space-y-6">
          {ordered.map((g, i) => (
            <motion.div
              key={g.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              className={cn('relative flex gap-5 md:w-1/2', i % 2 === 0 ? 'md:pr-10' : 'md:ml-auto md:flex-row-reverse md:pl-10')}
            >
              {/* node on the line */}
              <span
                className={cn(
                  'absolute left-0 top-6 z-10 grid h-10 w-10 -translate-x-1/2 place-items-center rounded-full border-2 bg-background font-mono text-[11px] font-bold transition-all duration-300 md:left-auto',
                  i % 2 === 0 ? 'md:right-0 md:translate-x-1/2' : 'md:left-0 md:-translate-x-1/2',
                  g.progress > 0 ? 'border-primary text-primary' : 'border-border text-muted-foreground'
                )}
              >
                {String(g.rank).padStart(2, '0')}
              </span>

              <Card className={cn(
                'group ml-10 w-full overflow-hidden transition-all duration-300 hover:border-primary/35 hover:shadow-md md:ml-0',
                justStarted === g.id && 'node-glow border-primary/50'
              )}>
                <CardContent className="p-0">
                  <div className="p-4.5 px-5 pt-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="text-[15px] font-semibold tracking-tight transition-colors group-hover:text-primary">
                          {g.name}
                        </h3>
                        <p className="mt-0.5 text-xs text-muted-foreground">{g.tagline}</p>
                      </div>
                      <StatusBadge status={g.status} />
                    </div>

                    <div className="mt-3 flex items-center gap-2.5">
                      <ProgressBar value={g.progress} barClassName={g.progress > 0 ? undefined : 'bg-stone-400/50'} />
                      <span className="w-9 shrink-0 text-right text-[11px] tabular-nums text-muted-foreground">{g.progress}%</span>
                    </div>

                    <div className="mt-3.5 grid gap-2 text-[11.5px] text-muted-foreground sm:grid-cols-2">
                      <div className="flex items-start gap-1.5">
                        <Flag className="mt-0.5 h-3 w-3 shrink-0 text-primary/70" />
                        <span className="min-w-0">
                          <span className="font-medium text-foreground/70">Prereqs:</span>{' '}
                          {g.prerequisites.join(' · ')}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5">
                        <Clock3 className="mt-0.5 h-3 w-3 shrink-0 text-primary/70" />
                        <span className="min-w-0">
                          <span className="font-medium text-foreground/70">Scope:</span> {g.estimatedScope}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5 sm:col-span-2">
                        <BookMarked className="mt-0.5 h-3 w-3 shrink-0 text-primary/70" />
                        <span className="min-w-0">
                          <span className="font-medium text-foreground/70">Project:</span> {g.suggestedProjects[0]}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5 sm:col-span-2">
                        <span className="mt-0.5 h-3 w-3 shrink-0 text-center font-mono text-[10px] leading-3 text-primary/70">§</span>
                        <span className="min-w-0 italic">{g.notes}</span>
                      </div>
                    </div>

                    <div className="mt-3.5 flex flex-wrap gap-1">
                      {g.technologies.slice(0, 4).map((t) => (
                        <span key={t} className="rounded border bg-secondary/50 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                          {t}
                        </span>
                      ))}
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t pt-3">
                      <DifficultyTag level={g.difficulty} />
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 gap-1.5 overflow-hidden text-xs transition-all duration-300"
                          onClick={() => handleStart(g.id)}
                        >
                          {justStarted === g.id ? (
                            <span className="flex items-center gap-1.5 text-primary">
                              Added to active research <ArrowRight className="h-3 w-3" />
                            </span>
                          ) : (
                            'Start Research'
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 text-xs"
                          onClick={() => {
                            setView('gaps')
                            openTopic(g.id, 'gap')
                          }}
                        >
                          Details
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Terminal node */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="relative mt-6 flex justify-start md:justify-center"
        >
          <div className="ml-10 rounded-xl border bg-primary px-5 py-3 text-primary-foreground shadow-lg shadow-primary/20 md:ml-0">
            <div className="text-[13px] font-semibold">Production-Grade Engineer</div>
            <div className="text-[11px] opacity-80">the connected layer, not more frameworks</div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
