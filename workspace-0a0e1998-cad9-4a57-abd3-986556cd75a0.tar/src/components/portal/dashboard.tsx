'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowRight, ArrowUpRight, Clock3, FlaskConical, Sparkles, TrendingUp } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { DOMAINS, GAPS, HERO_FLOW, OVERALL_PROGRESS, RECOMMENDED_NEXT, STATS } from '@/lib/portal'
import { ProgressBar, StatusBadge } from './atoms'

/* ── Parallax roadmap flow ─────────────────────────────── */

function RoadmapFlow() {
  const ref = useRef<HTMLDivElement>(null)
  const [tilt, setTilt] = useState({ x: 0, y: 0 })
  const [hovered, setHovered] = useState<number | null>(null)

  const onMove = (e: React.MouseEvent) => {
    const rect = ref.current?.getBoundingClientRect()
    if (!rect) return
    const px = (e.clientX - rect.left) / rect.width - 0.5
    const py = (e.clientY - rect.top) / rect.height - 0.5
    setTilt({ x: px, y: py })
  }

  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => {
        setTilt({ x: 0, y: 0 })
        setHovered(null)
      }}
      className="relative rounded-2xl border bg-card/70 p-5 shadow-sm sm:p-7"
      aria-label="Research roadmap flow"
    >
      <div
        className="pointer-events-none absolute inset-0 rounded-2xl grid-bg opacity-60"
        style={{ transform: `translate(${tilt.x * -8}px, ${tilt.y * -8}px)` }}
      />
      <div className="relative">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-2">
          <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
            Research Stack Order — from the Roadmap Gaps Review
          </div>
          <div className="hidden items-center gap-1.5 text-[11px] text-muted-foreground sm:flex">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
            </span>
            reactive · move your cursor
          </div>
        </div>

        {/* Desktop: horizontal scroll rail */}
        <div className="hidden lg:block">
          <div
            className="flex items-stretch gap-2 overflow-x-auto pb-2 pt-1 scrollbar-slim"
            style={{ transform: `perspective(1100px) rotateX(${tilt.y * -2.2}deg) rotateY(${tilt.x * 2.6}deg)`, transition: 'transform 120ms ease-out' }}
          >
            {HERO_FLOW.map((step, i) => (
              <motion.div
                key={step.label}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.055, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                className="flex items-stretch"
                onMouseEnter={() => setHovered(i)}
              >
                <motion.div
                  animate={{
                    scale: hovered === i ? 1.045 : 1,
                    y: hovered === i ? -3 : 0,
                    translateY: hovered !== null && hovered !== i ? Math.abs(hovered - i) === 1 ? 2 : 0 : 0,
                  }}
                  transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                  className={cn(
                    'flex min-w-[124px] max-w-[170px] cursor-default flex-col justify-between rounded-xl border bg-card px-3.5 py-3 transition-shadow duration-300',
                    hovered === i ? 'node-glow border-primary/40' : 'shadow-sm'
                  )}
                >
                  <div className="mb-2 font-mono text-[10px] font-semibold text-primary/70">
                    {String(i + 1).padStart(2, '0')}
                  </div>
                  <div className="text-[12.5px] font-medium leading-snug">{step.label}</div>
                  <div className="mt-1.5 text-[10.5px] italic text-muted-foreground">{step.hint}</div>
                </motion.div>
                {i < HERO_FLOW.length - 1 && (
                  <div className="grid place-items-center px-0.5 text-primary/50">
                    <ArrowRight className="h-4 w-4" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Mobile/tablet: vertical chain */}
        <div className="space-y-1 lg:hidden">
          {HERO_FLOW.map((step, i) => (
            <motion.div
              key={step.label}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05, duration: 0.4 }}
              className="flex items-center gap-2.5"
            >
              <div
                className={cn(
                  'flex-1 rounded-xl border bg-card px-4 py-2.5 transition-all duration-300',
                  hovered === i ? 'node-glow border-primary/40' : ''
                )}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-[10px] font-semibold text-primary/70">{String(i + 1).padStart(2, '0')}</span>
                  <span className="text-[13px] font-medium">{step.label}</span>
                </div>
              </div>
              {i < HERO_FLOW.length - 1 && <ArrowDown className="h-3.5 w-3.5 text-primary/50" />}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ── Progress ring ─────────────────────────────────────── */

function ProgressRing({ value, size = 132 }: { value: number; size?: number }) {
  const [shown, setShown] = useState(0)
  useEffect(() => {
    const t = setTimeout(() => setShown(value), 150)
    return () => clearTimeout(t)
  }, [value])
  const r = (size - 16) / 2
  const c = 2 * Math.PI * r
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth="9" className="stroke-muted" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth="9"
          strokeLinecap="round"
          className="stroke-primary transition-[stroke-dashoffset] duration-1000 ease-out"
          strokeDasharray={c}
          strokeDashoffset={c - (shown / 100) * c}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="text-2xl font-semibold tabular-nums tracking-tight">{value}%</div>
          <div className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">coverage</div>
        </div>
      </div>
    </div>
  )
}

/* ── Mini relationship map ─────────────────────────────── */

function RelationshipMap() {
  const { setView } = usePortal()
  const nodes = [
    { id: 'linux', label: 'Linux', x: 12, y: 18, gap: true },
    { id: 'docker', label: 'Docker', x: 46, y: 10, gap: false },
    { id: 'k8s', label: 'Kubernetes', x: 78, y: 22, gap: false },
    { id: 'queues', label: 'Kafka', x: 18, y: 62, gap: true },
    { id: 'obs', label: 'Observability', x: 55, y: 70, gap: true },
    { id: 'prod', label: 'Production', x: 86, y: 58, gap: false },
  ]
  const edges: [string, string][] = [
    ['linux', 'docker'],
    ['docker', 'k8s'],
    ['linux', 'queues'],
    ['queues', 'obs'],
    ['k8s', 'prod'],
    ['obs', 'prod'],
  ]
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]))
  return (
    <div className="relative h-52 rounded-xl border bg-secondary/30">
      <svg className="absolute inset-0 h-full w-full" aria-hidden>
        {edges.map(([a, b], i) => (
          <line
            key={i}
            x1={`${byId[a].x}%`}
            y1={`${byId[a].y}%`}
            x2={`${byId[b].x}%`}
            y2={`${byId[b].y}%`}
            className="stroke-primary/25"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
        ))}
      </svg>
      {nodes.map((n) => (
        <button
          key={n.id}
          onClick={() => setView('graph')}
          className={cn(
            'absolute -translate-x-1/2 -translate-y-1/2 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all duration-300 hover:scale-110 hover:node-glow',
            n.gap ? 'border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-400' : 'border-primary/30 bg-primary/10 text-primary'
          )}
          style={{ left: `${n.x}%`, top: `${n.y}%` }}
        >
          {n.label}
        </button>
      ))}
      <div className="absolute bottom-2 right-3 text-[10px] text-muted-foreground">technology relationships → graph view</div>
    </div>
  )
}

/* ── Dashboard view ────────────────────────────────────── */

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
}
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const } },
}

export function DashboardView() {
  const { setView, openTopic } = usePortal()
  const topGaps = useMemo(() => [...GAPS].sort((a, b) => a.rank - b.rank).slice(0, 6), [])
  const knownDomains = useMemo(() => [...DOMAINS].sort((a, b) => b.coverage - a.coverage), [])

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      {/* Hero */}
      <motion.section variants={item} className="relative overflow-hidden rounded-2xl border bg-card p-6 shadow-sm sm:p-10">
        <div className="pointer-events-none absolute inset-0 grid-bg opacity-50" />
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-[0.07]"
          style={{ background: 'radial-gradient(circle, var(--primary), transparent 65%)' }}
        />
        <div className="relative max-w-3xl">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border bg-secondary/70 px-3 py-1 text-[11px] font-medium text-muted-foreground">
            <Sparkles className="h-3 w-3 text-primary" />
            Engineering Research Operating System
            <span className="mx-1 h-3 w-px bg-border" />
            based on the Roadmap Gaps Review
          </div>
          <h1 className="text-balance text-3xl font-semibold leading-[1.12] tracking-tight sm:text-[2.6rem]">
            Turn Your Knowledge Gaps Into a{' '}
            <span className="text-gradient">Research Roadmap</span>
          </h1>
          <p className="mt-4 max-w-2xl text-[15px] leading-relaxed text-muted-foreground">
            Explore software engineering, computer science, cloud, DevOps, AI, MLOps, and production engineering through
            one structured research workspace.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Button size="lg" onClick={() => setView('roadmap')} className="group gap-2">
              Start Research
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Button>
            <Button size="lg" variant="outline" onClick={() => setView('gaps')}>
              Review Gaps
            </Button>
            <div className="ml-1 flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" />{STATS.researchHours}h logged</span>
              <span className="flex items-center gap-1.5"><FlaskConical className="h-3.5 w-3.5" />{STATS.projectsActive} active projects</span>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Roadmap flow */}
      <motion.section variants={item} className="mt-6">
        <RoadmapFlow />
      </motion.section>

      {/* Widget grid */}
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {/* Research progress */}
        <motion.div variants={item}>
          <Card className="h-full">
            <CardContent className="flex h-full flex-col items-center gap-4 p-5">
              <div className="self-start text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Research Progress
              </div>
              <ProgressRing value={OVERALL_PROGRESS} />
              <div className="grid w-full grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-secondary/60 px-2 py-2">
                  <div className="text-sm font-semibold tabular-nums">{STATS.topicsCompleted}</div>
                  <div className="text-[10px] text-muted-foreground">completed</div>
                </div>
                <div className="rounded-lg bg-secondary/60 px-2 py-2">
                  <div className="text-sm font-semibold tabular-nums">{STATS.topicsInProgress}</div>
                  <div className="text-[10px] text-muted-foreground">in progress</div>
                </div>
                <div className="rounded-lg bg-secondary/60 px-2 py-2">
                  <div className="text-sm font-semibold tabular-nums">{STATS.topicsNotStarted}</div>
                  <div className="text-[10px] text-muted-foreground">queued</div>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="gap-1 self-end text-xs" onClick={() => setView('progress')}>
                Analytics <ArrowUpRight className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Current knowledge areas */}
        <motion.div variants={item}>
          <Card className="h-full">
            <CardContent className="p-5">
              <div className="flex items-center justify-between pb-1">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Current Knowledge Areas
                </div>
                <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
              </div>
              <div className="space-y-2.5 pt-2">
                {knownDomains.slice(0, 5).map((d, i) => (
                  <button key={d.id} className="group w-full text-left" onClick={() => setView('knowledge-map')}>
                    <div className="flex items-center justify-between pb-1 text-xs">
                      <span className="font-medium transition-colors group-hover:text-primary">{d.name}</span>
                      <span className="tabular-nums text-muted-foreground">{d.coverage}%</span>
                    </div>
                    <ProgressBar value={d.coverage} delay={i * 60} barClassName={d.coverage >= 70 ? 'bg-emerald-500' : undefined} />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Missing knowledge areas */}
        <motion.div variants={item}>
          <Card className="h-full border-amber-500/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between pb-2">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Missing Knowledge Areas
                </div>
                <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-700 dark:text-amber-400">
                  {STATS.gapsTotal} gaps
                </span>
              </div>
              <div className="space-y-1">
                {topGaps.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => {
                      setView('gaps')
                      openTopic(g.id, 'gap')
                    }}
                    className="group flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors duration-200 hover:bg-secondary"
                  >
                    <span className="font-mono text-[10px] font-semibold text-amber-600/80 dark:text-amber-400/80">
                      {String(g.rank).padStart(2, '0')}
                    </span>
                    <span className="flex-1 truncate text-xs font-medium group-hover:text-primary">{g.name}</span>
                    <ArrowUpRight className="h-3 w-3 shrink-0 text-muted-foreground/50 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recommended next topics */}
        <motion.div variants={item} className="md:col-span-2">
          <Card className="h-full">
            <CardContent className="p-5">
              <div className="pb-3 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Recommended Next Topics
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {RECOMMENDED_NEXT.map((r) => (
                  <button
                    key={r.title}
                    onClick={() => {
                      setView('gaps')
                      openTopic(r.gapId, 'gap')
                    }}
                    className="group flex items-start justify-between gap-3 rounded-xl border bg-card p-3.5 text-left transition-all duration-300 hover:border-primary/35 hover:shadow-sm"
                  >
                    <div className="min-w-0">
                      <div className="truncate text-[13px] font-medium group-hover:text-primary">{r.title}</div>
                      <div className="mt-0.5 text-[11px] text-muted-foreground">{r.reason}</div>
                    </div>
                    <div className="shrink-0 rounded-md bg-secondary px-1.5 py-1 text-[10px] font-medium tabular-nums text-muted-foreground">
                      {r.minutes}m
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Technology relationships */}
        <motion.div variants={item}>
          <Card className="h-full">
            <CardContent className="flex h-full flex-col gap-3 p-5">
              <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Technology Relationships
              </div>
              <RelationshipMap />
            </CardContent>
          </Card>
        </motion.div>

        {/* Active gap strip */}
        <motion.div variants={item} className="md:col-span-3">
          <Card>
            <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
              <div className="min-w-56">
                <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Active Research Thread
                </div>
                <div className="mt-1 text-[15px] font-medium">{GAPS[6].name}</div>
                <div className="text-xs text-muted-foreground">Priority #07 · Producer → Broker → Consumer</div>
              </div>
              <div className="flex flex-1 items-center gap-3">
                <Progress value={GAPS[6].progress} className="h-1.5" />
                <span className="text-xs tabular-nums text-muted-foreground">{GAPS[6].progress}%</span>
              </div>
              <StatusBadge status={GAPS[6].status} />
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => { setView('gaps'); openTopic(GAPS[6].id, 'gap') }}>
                Open workspace <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  )
}
