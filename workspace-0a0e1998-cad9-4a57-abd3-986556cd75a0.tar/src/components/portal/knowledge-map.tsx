'use client'

import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Binary, Code2, Network, Database, Cloud, Container, Activity, Workflow, BrainCircuit, Cpu, Sparkles, ChevronDown } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { DOMAINS, type Domain, type DomainId } from '@/lib/portal'
import { ProgressBar, SectionHeading, StatusBadge, DifficultyTag } from './atoms'

const ICONS: Record<string, typeof Binary> = {
  Binary, Code2, Network, Database, Cloud, Container, Activity, Workflow, BrainCircuit, Cpu, Sparkles,
}

const FILTERS: { id: DomainId | 'all'; label: string }[] = [
  { id: 'all', label: 'All Domains' },
  ...DOMAINS.map((d) => ({ id: d.id, label: d.name })),
]

function DomainCard({ domain, index, open, onToggle }: { domain: Domain; index: number; open: boolean; onToggle: () => void }) {
  const { openTopic, setView, setMapDomain } = usePortal()
  const Icon = ICONS[domain.icon] ?? Binary

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.04, 0.3), ease: [0.22, 1, 0.36, 1] }}
    >
      <Card
        className={cn(
          'group h-full overflow-hidden transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md',
          open && 'node-glow border-primary/35'
        )}
      >
        <CardContent className="p-0">
          <button onClick={onToggle} className="w-full p-5 text-left" aria-expanded={open}>
            <div className="flex items-start gap-3.5">
              <span
                className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border transition-all duration-300 group-hover:scale-105"
                style={{ background: `${domain.color}14`, color: domain.color, borderColor: `${domain.color}30` }}
              >
                <Icon className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-[15px] font-semibold tracking-tight">{domain.name}</h3>
                  <ChevronDown className={cn('h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-300', open && 'rotate-180')} />
                </div>
                <div className="mt-0.5 flex items-center gap-2 text-[11px] text-muted-foreground">
                  <span>{domain.topics.length} topics</span>
                  <span className="h-0.5 w-0.5 rounded-full bg-current" />
                  <span>{domain.topics.filter((t) => t.status === 'completed').length} covered</span>
                </div>
                <div className="mt-3 flex items-center gap-2.5">
                  <ProgressBar value={domain.coverage} />
                  <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">{domain.coverage}%</span>
                </div>
              </div>
            </div>
          </button>

          <AnimatePresence initial={false}>
            {open && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                className="overflow-hidden"
              >
                <div className="border-t px-5 pb-5 pt-4">
                  <p className="pb-3 text-xs leading-relaxed text-muted-foreground">{domain.description}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {domain.topics.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => openTopic(t.id, 'topic')}
                        onMouseEnter={(e) => (e.currentTarget.style.borderColor = `${domain.color}66`)}
                        onMouseLeave={(e) => (e.currentTarget.style.borderColor = '')}
                        className="group/t rounded-lg border bg-secondary/40 px-2.5 py-1.5 text-left transition-all duration-200 hover:bg-primary/5"
                      >
                        <span className="flex items-center gap-1.5 text-xs font-medium">
                          <span
                            className={cn(
                              'h-1.5 w-1.5 rounded-full',
                              t.status === 'completed' && 'bg-emerald-500',
                              t.status === 'in-progress' && 'bg-amber-500',
                              t.status === 'not-started' && 'bg-stone-400/60'
                            )}
                          />
                          {t.name}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 gap-1 text-xs"
                      onClick={() => {
                        setMapDomain(domain.id)
                        setView('explorer')
                      }}
                    >
                      Explore in Research →
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  )
}

export function KnowledgeMapView() {
  const { mapDomain, setMapDomain } = usePortal()
  const [expanded, setExpanded] = useState<Set<string>>(new Set())

  const visible = useMemo(
    () => (mapDomain === 'all' ? DOMAINS : DOMAINS.filter((d) => d.id === mapDomain)),
    [mapDomain]
  )

  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHeading
          eyebrow="Knowledge Map"
          title="Eleven domains, one connected body of knowledge"
          sub="Every node below comes directly from the Roadmap Gaps Review. Expand a domain to see its topics; click any topic to open its research workspace."
        />
      </div>

      <div className="mt-6 flex flex-wrap gap-1.5">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            onClick={() => setMapDomain(f.id)}
            className={cn(
              'rounded-full border px-3 py-1.5 text-xs font-medium transition-all duration-300',
              mapDomain === f.id
                ? 'border-primary/50 bg-primary/10 text-primary'
                : 'text-muted-foreground hover:border-primary/30 hover:text-foreground'
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <motion.div layout className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {visible.map((d, i) => (
            <DomainCard key={d.id} domain={d} index={i} open={expanded.has(d.id)} onToggle={() => toggle(d.id)} />
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
