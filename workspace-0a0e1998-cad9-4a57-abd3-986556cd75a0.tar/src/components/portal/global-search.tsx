'use client'

import { useEffect, useMemo, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Search, CornerDownLeft } from 'lucide-react'
import { searchPortal, SEARCH_INDEX, type SearchEntry } from '@/lib/portal'
import { usePortal } from '@/lib/store'
import { StatusBadge, DifficultyTag } from './atoms'

const SUGGESTIONS = ['Kafka', 'OAuth 2.0', 'CAP theorem', 'RAG evaluation', 'Terraform', 'Distributed systems', 'OpenTelemetry']

const KIND_CLS: Record<SearchEntry['kind'], string> = {
  topic: 'bg-primary/10 text-primary',
  gap: 'bg-amber-500/10 text-amber-700 dark:text-amber-400',
  comparison: 'bg-violet-500/10 text-violet-700 dark:text-violet-400',
  project: 'bg-emerald-600/10 text-emerald-700 dark:text-emerald-400',
}

export function GlobalSearch() {
  const { searchOpen, setSearchOpen, openTopic, setView, setCopilotOpen } = usePortal()
  const [q, setQ] = useState('')
  const [active, setActive] = useState(0)

  const results = useMemo(() => (q.trim() ? searchPortal(q) : []), [q])
  const showDefaults = !q.trim()

  // reset cursor when query/dialog changes (state-adjust-during-render pattern)
  const sig = `${q}|${searchOpen}`
  const [prevSig, setPrevSig] = useState(sig)
  if (prevSig !== sig) {
    setPrevSig(sig)
    setActive(0)
  }

  const open = (e: SearchEntry) => {
    setSearchOpen(false)
    setQ('')
    if (e.kind === 'comparison') {
      setView('comparison')
    } else if (e.kind === 'project') {
      setView('projects')
    } else if (e.kind === 'gap') {
      setView('gaps')
      openTopic(e.id, 'gap')
    } else if (e.kind === 'topic') {
      setView('explorer')
      openTopic(e.id, 'topic')
    }
  }

  const defaultEntries = useMemo(
    () => SEARCH_INDEX.filter((e) => SUGGESTIONS.some((s) => e.name.toLowerCase().includes(s.toLowerCase()))).slice(0, 6),
    []
  )

  const onKeyDown = (ev: React.KeyboardEvent) => {
    const list = showDefaults ? defaultEntries : results
    if (ev.key === 'ArrowDown') {
      ev.preventDefault()
      setActive((a) => Math.min(a + 1, list.length - 1))
    } else if (ev.key === 'ArrowUp') {
      ev.preventDefault()
      setActive((a) => Math.max(a - 1, 0))
    } else if (ev.key === 'Enter' && list[active]) {
      open(list[active])
    }
  }

  const list = showDefaults ? defaultEntries : results

  return (
    <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
      <DialogContent className="max-w-xl gap-0 overflow-hidden p-0 top-[18%] translate-y-0">
        <DialogHeader className="sr-only">
          <DialogTitle>Search the research portal</DialogTitle>
        </DialogHeader>
        <div className="flex items-center gap-2.5 border-b px-4">
          <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
          <Input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Search a technology, concept, architecture, or research topic…"
            className="h-12 border-0 bg-transparent px-0 text-sm shadow-none focus-visible:ring-0"
            aria-label="Search"
          />
        </div>
        <div className="max-h-[46vh] overflow-y-auto p-2 scrollbar-slim">
          {showDefaults && (
            <div className="px-2 pb-2 pt-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">
              Try searching
            </div>
          )}
          {list.length === 0 && !showDefaults && (
            <div className="px-3 py-8 text-center text-sm text-muted-foreground">
              No results for “{q}”. Try “Kafka”, “CAP”, or “observability”.
            </div>
          )}
          {list.map((e, i) => (
            <button
              key={e.kind + e.id}
              onMouseEnter={() => setActive(i)}
              onClick={() => open(e)}
              className={`flex w-full items-start gap-3 rounded-lg px-3 py-2.5 text-left transition-colors duration-150 ${
                i === active ? 'bg-secondary' : ''
              }`}
            >
              <span className={`mt-0.5 rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${KIND_CLS[e.kind]}`}>
                {e.kind === 'topic' ? 'TOPIC' : e.kind === 'gap' ? 'GAP' : e.kind === 'comparison' ? 'VS' : 'LAB'}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate text-[13px] font-medium">{e.name}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{e.domain}</span>
                </span>
                <span className="mt-0.5 block truncate text-xs text-muted-foreground">{e.summary}</span>
              </span>
              {e.status !== 'reference' && <StatusBadge status={e.status as never} className="mt-0.5 shrink-0" />}
              {i === active && <CornerDownLeft className="mt-1 h-3.5 w-3.5 shrink-0 text-muted-foreground" />}
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between border-t bg-secondary/40 px-4 py-2 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-3">
            <span><kbd className="rounded border bg-background px-1 font-mono">↑↓</kbd> navigate</span>
            <span><kbd className="rounded border bg-background px-1 font-mono">↵</kbd> open</span>
          </span>
          <button
            className="flex items-center gap-1 transition-colors hover:text-primary"
            onClick={() => {
              setSearchOpen(false)
              setCopilotOpen(true)
            }}
          >
            Ask the Copilot instead
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export { DifficultyTag }
