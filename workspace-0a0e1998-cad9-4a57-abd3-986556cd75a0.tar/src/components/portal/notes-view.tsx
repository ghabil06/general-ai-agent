'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  BookOpen,
  FileText,
  Bookmark,
  HelpCircle,
  FlaskConical,
  FolderKanban,
  Library,
  Link2,
  Paperclip,
  Code2,
  Search,
  Star,
} from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { NOTES } from '@/lib/portal'
import { SectionHeading } from './atoms'

const SECTIONS = [
  { id: 'Notes', icon: BookOpen },
  { id: 'Saved Topics', icon: Star },
  { id: 'Research Papers', icon: FileText },
  { id: 'Documentation', icon: FileText },
  { id: 'Bookmarks', icon: Bookmark },
  { id: 'Questions', icon: HelpCircle },
  { id: 'Experiments', icon: FlaskConical },
  { id: 'Projects', icon: FolderKanban },
  { id: 'References', icon: Library },
]

const KIND_ICON: Record<string, typeof BookOpen> = {
  note: BookOpen,
  paper: FileText,
  doc: FileText,
  bookmark: Bookmark,
  question: HelpCircle,
  experiment: FlaskConical,
  reference: Library,
  snippet: Code2,
}

export function NotesView() {
  const { savedTopics, openTopic } = usePortal()
  const [section, setSection] = useState('Notes')
  const [q, setQ] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [draft, setDraft] = useState('')

  const items = useMemo(() => {
    let list = NOTES.filter((n) => n.section === section)
    if (section === 'Saved Topics') {
      // dynamic: render saved topic ids as pseudo-items below
      list = []
    }
    if (q.trim()) {
      const lower = q.toLowerCase()
      list = NOTES.filter(
        (n) => n.title.toLowerCase().includes(lower) || n.excerpt.toLowerCase().includes(lower) || n.tags.join(' ').toLowerCase().includes(lower)
      )
    }
    return list
  }, [section, q])

  const current = NOTES.find((n) => n.id === selected)

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Research Notes · Knowledge Base"
        title="Your research workspace"
        sub="Notes, papers, documentation, bookmarks, questions, experiments, and references — attach links, PDFs, code snippets, and findings to everything you study."
      />

      <div className="mt-6 grid gap-5 lg:grid-cols-[230px_1fr]">
        {/* Sections rail */}
        <aside className="space-y-1">
          <div className="relative mb-3">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search notes…"
              className="h-8.5 bg-secondary/50 pl-8 text-xs"
              aria-label="Search notes"
            />
          </div>
          {SECTIONS.map((s) => {
            const Icon = s.icon
            const count = s.id === 'Saved Topics' ? savedTopics.length : NOTES.filter((n) => n.section === s.id).length
            return (
              <button
                key={s.id}
                onClick={() => {
                  setSection(s.id)
                  setSelected(null)
                }}
                className={cn(
                  'flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] transition-colors duration-200',
                  section === s.id && !q
                    ? 'bg-secondary font-medium text-foreground'
                    : 'text-muted-foreground hover:bg-secondary/60 hover:text-foreground'
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                <span className="flex-1 text-left">{s.id}</span>
                <span className="rounded-full bg-muted px-1.5 text-[10px] tabular-nums">{count}</span>
              </button>
            )
          })}
        </aside>

        {/* Document area */}
        <div className="min-w-0 space-y-4">
          {section === 'Saved Topics' && !q ? (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="grid gap-2 sm:grid-cols-2">
              {savedTopics.length === 0 && (
                <p className="col-span-full rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
                  Nothing saved yet — save topics from the Research Gaps panel.
                </p>
              )}
              {savedTopics.map((id) => {
                const g = NOTES.find((n) => n.id === id)
                return (
                  <div key={id} className="rounded-xl border bg-card p-4">
                    <div className="flex items-center gap-2 pb-1 text-[11px] font-medium text-primary">
                      <Star className="h-3 w-3" /> Saved topic
                    </div>
                    <div className="text-[14px] font-semibold">{g?.title ?? id}</div>
                    <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{g?.excerpt}</p>
                  </div>
                )
              })}
              <button
                onClick={() => openTopic('git-gap', 'gap')}
                className="rounded-xl border border-dashed p-4 text-left text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                + Save more from Research Gaps
              </button>
            </motion.div>
          ) : (
            <>
              {/* Quick capture */}
              <div className="rounded-xl border bg-card p-3">
                <Textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={`Capture a finding for “${section}” — what did you learn, what surprised you, what to verify next…`}
                  className="min-h-20 resize-none border-0 bg-transparent p-2 text-[13px] shadow-none focus-visible:ring-0"
                />
                <div className="flex items-center justify-between border-t pt-2">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs"><Link2 className="h-3 w-3" /> Link</Button>
                    <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs"><Paperclip className="h-3 w-3" /> PDF</Button>
                    <Button variant="ghost" size="sm" className="h-7 gap-1 text-xs"><Code2 className="h-3 w-3" /> Snippet</Button>
                  </div>
                  <Button
                    size="sm"
                    className="h-7 text-xs"
                    disabled={!draft.trim()}
                    onClick={() => {
                      setDraft('')
                    }}
                  >
                    Save note
                  </Button>
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                {items.map((n, i) => {
                  const Icon = KIND_ICON[n.kind] ?? BookOpen
                  const active = selected === n.id
                  return (
                    <motion.button
                      key={n.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: Math.min(i * 0.03, 0.2) }}
                      onClick={() => setSelected(active ? null : n.id)}
                      className={cn(
                        'rounded-xl border bg-card p-4 text-left transition-all duration-300 hover:border-primary/30 hover:shadow-sm',
                        active && 'node-glow border-primary/40'
                      )}
                    >
                      <div className="flex items-center gap-2 pb-1.5 text-[11px] font-medium text-muted-foreground">
                        <Icon className="h-3 w-3 text-primary" />
                        {n.kind}
                        <span className="ml-auto">{n.updated}</span>
                      </div>
                      <div className="text-[13.5px] font-semibold leading-snug">{n.title}</div>
                      <p className={cn('mt-1 text-xs leading-relaxed text-muted-foreground', active ? '' : 'line-clamp-2')}>
                        {n.excerpt}
                      </p>
                      <div className="mt-2.5 flex flex-wrap gap-1">
                        {n.tags.map((t) => (
                          <Badge key={t} variant="secondary" className="rounded px-1.5 py-0 text-[10px] font-normal">
                            {t}
                          </Badge>
                        ))}
                      </div>
                    </motion.button>
                  )
                })}
                {items.length === 0 && (
                  <p className="md:col-span-2 rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
                    No entries here yet.
                  </p>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
