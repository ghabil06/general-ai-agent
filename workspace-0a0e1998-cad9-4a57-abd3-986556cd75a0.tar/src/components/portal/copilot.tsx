'use client'

import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Sparkles,
  X,
  SendHorizonal,
  GitBranch,
  ListChecks,
  GitCompareArrows,
  Route,
  FileText,
  Workflow,
  Lightbulb,
  ShieldCheck,
  Brain,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { MarkdownLite } from './markdown-lite'

interface Msg {
  role: 'user' | 'assistant'
  content: string
}

const CAPABILITIES = [
  { icon: Brain, label: 'Explain a topic' },
  { icon: GitBranch, label: 'Find knowledge gaps' },
  { icon: ListChecks, label: 'Generate research questions' },
  { icon: GitCompareArrows, label: 'Compare technologies' },
  { icon: Route, label: 'Build a learning path' },
  { icon: FileText, label: 'Summarize research' },
  { icon: Workflow, label: 'Generate implementation tasks' },
  { icon: Lightbulb, label: 'Connect related concepts' },
  { icon: ShieldCheck, label: 'Evaluate understanding' },
]

const PROMPT_CHIPS = [
  'Explain CAP theorem simply',
  'How does Kafka fit into distributed systems?',
  'Build a learning path for MLOps',
  'What should I learn before Kubernetes?',
  'Compare Kafka and RabbitMQ',
  'Find gaps in my system-design knowledge',
]

const GREETING: Msg = {
  role: 'assistant',
  content: `**Research Copilot online.** I'm grounded in your Roadmap Gaps Review — 12 priority gaps, 11 knowledge domains, the works.

I can explain topics, compare technologies, build learning paths, generate research questions, and connect concepts across your roadmap. What are we studying?`,
}

export function CopilotPanel() {
  const { copilotOpen, setCopilotOpen } = usePortal()
  const [messages, setMessages] = useState<Msg[]>([GREETING])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, busy, copilotOpen])

  const send = async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || busy) return
    const next: Msg[] = [...messages, { role: 'user', content }]
    setMessages(next)
    setInput('')
    setBusy(true)
    try {
      const res = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.filter((m) => m !== GREETING) }),
      })
      const data = (await res.json()) as { reply: string }
      setMessages((m) => [...m, { role: 'assistant', content: data.reply }])
    } catch {
      setMessages((m) => [
        ...m,
        { role: 'assistant', content: 'The copilot service is unreachable right now — try again in a moment, or open the Research Gaps panel to continue manually.' },
      ])
    } finally {
      setBusy(false)
    }
  }

  return (
    <AnimatePresence>
      {copilotOpen && (
        <motion.aside
          initial={{ x: '100%', opacity: 0.5 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: '100%', opacity: 0.5 }}
          transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l bg-card shadow-2xl md:inset-y-3 md:rounded-2xl md:border"
          role="complementary"
          aria-label="Research Copilot"
        >
          {/* header */}
          <div className="flex items-center gap-3 border-b px-4 py-3.5">
            <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-primary/10 text-primary">
              <Sparkles className="h-4.5 w-4.5" />
              <span className="absolute -right-0.5 -top-0.5 flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-50" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full border-2 border-card bg-primary" />
              </span>
            </span>
            <div className="min-w-0 flex-1">
              <div className="text-[14px] font-semibold tracking-tight">Research Copilot</div>
              <div className="text-[11px] text-muted-foreground">grounded in the Roadmap Gaps Review</div>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCopilotOpen(false)} aria-label="Close copilot">
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* capabilities strip */}
          <div className="flex gap-1.5 overflow-x-auto border-b px-4 py-2.5 scrollbar-slim">
            {CAPABILITIES.map((c) => (
              <span
                key={c.label}
                className="flex shrink-0 items-center gap-1.5 rounded-full border bg-secondary/50 px-2.5 py-1 text-[10.5px] font-medium text-muted-foreground"
              >
                <c.icon className="h-3 w-3 text-primary" />
                {c.label}
              </span>
            ))}
          </div>

          {/* messages */}
          <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-4 py-4 scrollbar-slim">
            {messages.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}
              >
                <div
                  className={cn(
                    'max-w-[88%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed',
                    m.role === 'user'
                      ? 'rounded-br-md bg-primary text-primary-foreground'
                      : 'rounded-bl-md border bg-background'
                  )}
                >
                  {m.role === 'user' ? m.content : <MarkdownLite text={m.content} />}
                </div>
              </motion.div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="flex items-center gap-1.5 rounded-2xl rounded-bl-md border bg-background px-4 py-3">
                  {[0, 1, 2].map((d) => (
                    <span
                      key={d}
                      className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary/60"
                      style={{ animationDelay: `${d * 140}ms` }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* prompt chips */}
          {messages.length <= 1 && (
            <div className="flex flex-wrap gap-1.5 border-t px-4 pt-3">
              {PROMPT_CHIPS.map((c) => (
                <button
                  key={c}
                  onClick={() => send(c)}
                  className="rounded-full border bg-secondary/50 px-2.5 py-1.5 text-[11px] text-muted-foreground transition-all duration-200 hover:border-primary/40 hover:text-primary"
                >
                  {c}
                </button>
              ))}
            </div>
          )}

          {/* input */}
          <form
            className="flex items-center gap-2 border-t p-3"
            onSubmit={(e) => {
              e.preventDefault()
              send()
            }}
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about any topic, gap, or comparison…"
              className="h-9 rounded-xl bg-secondary/50 text-[13px]"
              aria-label="Message the copilot"
            />
            <Button type="submit" size="icon" className="h-9 w-9 shrink-0 rounded-xl" disabled={busy || !input.trim()} aria-label="Send">
              <SendHorizonal className="h-4 w-4" />
            </Button>
          </form>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}
