'use client'

import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import type { ResearchStatus, Difficulty } from '@/lib/portal/types'

export const STATUS_META: Record<ResearchStatus, { label: string; cls: string; dot: string }> = {
  completed: {
    label: 'Completed',
    cls: 'bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 border-emerald-600/25',
    dot: 'bg-emerald-500',
  },
  'in-progress': {
    label: 'In Progress',
    cls: 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/25',
    dot: 'bg-amber-500',
  },
  'not-started': {
    label: 'Not Started',
    cls: 'bg-muted text-muted-foreground border-border',
    dot: 'bg-stone-400',
  },
}

export function StatusBadge({ status, className }: { status: ResearchStatus; className?: string }) {
  const m = STATUS_META[status]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium leading-4',
        m.cls,
        className
      )}
    >
      <span className={cn('h-1.5 w-1.5 rounded-full', m.dot)} />
      {m.label}
    </span>
  )
}

const DIFF_META: Record<Difficulty, { cls: string; label: string }> = {
  Beginner: { cls: 'text-emerald-600 dark:text-emerald-400', label: 'Beginner' },
  Intermediate: { cls: 'text-amber-600 dark:text-amber-400', label: 'Intermediate' },
  Advanced: { cls: 'text-rose-600 dark:text-rose-400', label: 'Advanced' },
}

export function DifficultyTag({ level, className }: { level: Difficulty; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1 text-[11px] font-medium', DIFF_META[level].cls, className)}>
      <span className="tracking-widest opacity-60">●</span>
      {DIFF_META[level].label}
    </span>
  )
}

export function ProgressBar({
  value,
  className,
  barClassName,
  delay = 0,
}: {
  value: number
  className?: string
  barClassName?: string
  delay?: number
}) {
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full bg-muted', className)}>
      <div
        className={cn('progress-fill h-full rounded-full bg-primary', barClassName)}
        style={{ width: `${Math.max(2, value)}%`, transitionDelay: `${delay}ms` }}
      />
    </div>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  sub,
  className,
}: {
  eyebrow?: string
  title: string
  sub?: string
  className?: string
}) {
  return (
    <div className={cn('space-y-1.5', className)}>
      {eyebrow && (
        <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">{eyebrow}</div>
      )}
      <h2 className="text-xl font-semibold tracking-tight md:text-2xl">{title}</h2>
      {sub && <p className="max-w-2xl text-sm text-muted-foreground">{sub}</p>}
    </div>
  )
}
