'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { GitBranch, Info } from 'lucide-react'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { GRAPHS, GAPS, allTopics, type ResearchGraph } from '@/lib/portal'
import { SectionHeading, StatusBadge } from './atoms'

const NODE_W = 150
const NODE_H = 46
const GAP_X = 110
const GAP_Y = 86

function layout(g: ResearchGraph) {
  // simple layered layout following the DAG edges (chains mostly)
  const depth = g.nodes.map(() => 0)
  for (let iter = 0; iter < g.nodes.length; iter++) {
    for (const [a, b] of g.edges) depth[b] = Math.max(depth[b], depth[a] + 1)
  }
  const byDepth = new Map<number, number[]>()
  g.nodes.forEach((_, i) => {
    const arr = byDepth.get(depth[i]) ?? []
    arr.push(i)
    byDepth.set(depth[i], arr)
  })
  const pos = g.nodes.map((_, i) => ({ x: 0, y: 0 }))
  let maxCols = 0
  byDepth.forEach((arr, d) => {
    maxCols = Math.max(maxCols, arr.length)
    arr.forEach((nodeIdx, row) => {
      pos[nodeIdx] = { x: 60 + d * (NODE_W + GAP_X), y: 50 + row * (NODE_H + GAP_Y) }
    })
  })
  const width = 120 + depth.length * (NODE_W + GAP_X)
  const height = 100 + maxCols * (NODE_H + GAP_Y)
  return { pos, width: Math.max(width, 640), height }
}

const STATUS_NODE_CLS = {
  completed: 'border-emerald-500/50 bg-emerald-500/[0.08] text-emerald-700 dark:text-emerald-400',
  'in-progress': 'border-amber-500/50 bg-amber-500/[0.08] text-amber-700 dark:text-amber-400',
  'not-started': 'border-border bg-card text-foreground/70',
}

export function GraphView() {
  const { openTopic } = usePortal()
  const [graphId, setGraphId] = useState(GRAPHS[0].id)
  const [hover, setHover] = useState<number | null>(null)
  const g = GRAPHS.find((x) => x.id === graphId)!
  const { pos, width, height } = useMemo(() => layout(g), [g])

  const connected = useMemo(() => {
    if (hover === null) return null
    const set = new Set<number>([hover])
    for (const [a, b] of g.edges) {
      if (a === hover) set.add(b)
      if (b === hover) set.add(a)
    }
    return set
  }, [hover, g])

  const findTopicForNode = (label: string) => {
    // best-effort mapping: match topic/gap by name inclusion
    const l = label.toLowerCase().replace(/[^a-z0-9 ]/g, '')
    const t = allTopics().find((x) => {
      const xn = x.name.toLowerCase().replace(/[^a-z0-9 ]/g, '')
      return xn === l || xn.includes(l) || l.includes(xn)
    })
    if (t) return { id: t.id, kind: 'topic' as const }
    const gp = GAPS.find((x) => {
      const xn = x.name.toLowerCase().replace(/[^a-z0-9 ]/g, '')
      return xn === l || xn.includes(l) || l.includes(xn)
    })
    if (gp) return { id: gp.id, kind: 'gap' as const }
    return null
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Research Graph"
        title="Dependency chains, visualized"
        sub="Hover a node to light up its dependencies; click to open the research workspace. Chains follow the sequences called out in the review."
      />

      <div className="mt-6 flex flex-wrap gap-1.5">
        {GRAPHS.map((x) => (
          <button
            key={x.id}
            onClick={() => {
              setGraphId(x.id)
              setHover(null)
            }}
            className={cn(
              'rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all duration-300',
              graphId === x.id
                ? 'border-primary/50 bg-primary/10 text-primary'
                : 'text-muted-foreground hover:border-primary/30 hover:text-foreground'
            )}
          >
            {x.title}
          </button>
        ))}
      </div>

      <motion.div
        key={g.id}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="mt-4"
      >
        <div className="flex items-start gap-2.5 rounded-xl border bg-secondary/40 px-4 py-3">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <p className="text-xs leading-relaxed text-muted-foreground">{g.description}</p>
        </div>

        <div className="mt-4 overflow-x-auto rounded-xl border bg-card p-2 scrollbar-slim">
          <div className="relative grid-bg" style={{ width, height, minWidth: '100%' }}>
            <svg className="absolute inset-0 h-full w-full" aria-hidden>
              {g.edges.map(([a, b], i) => {
                const pa = pos[a]
                const pb = pos[b]
                const activeEdge = connected !== null && connected.has(a) && connected.has(b)
                const x1 = pa.x + NODE_W
                const y1 = pa.y + NODE_H / 2
                const x2 = pb.x
                const y2 = pb.y + NODE_H / 2
                const mx = (x1 + x2) / 2
                return (
                  <path
                    key={i}
                    d={`M ${x1} ${y1} C ${mx} ${y1}, ${mx} ${y2}, ${x2} ${y2}`}
                    fill="none"
                    strokeWidth={activeEdge ? 2.4 : 1.6}
                    className={cn(
                      'transition-all duration-300',
                      activeEdge ? 'stroke-primary' : 'stroke-border'
                    )}
                    markerEnd="url(#arrow)"
                  />
                )
              })}
              <defs>
                <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M 0 1 L 9 5 L 0 9" fill="none" className="stroke-primary/60" strokeWidth="1.6" strokeLinecap="round" />
                </marker>
              </defs>
            </svg>

            {g.nodes.map((n, i) => {
              const dim = connected !== null && !connected.has(i)
              const lit = connected !== null && connected.has(i)
              return (
                <button
                  key={n.id}
                  onMouseEnter={() => setHover(i)}
                  onMouseLeave={() => setHover(null)}
                  onFocus={() => setHover(i)}
                  onClick={() => {
                    const found = findTopicForNode(n.label)
                    if (found) openTopic(found.id, found.kind)
                  }}
                  style={{ left: pos[i].x, top: pos[i].y, width: NODE_W }}
                  className={cn(
                    'absolute flex items-center justify-between gap-2 rounded-lg border px-3 py-2.5 text-left shadow-sm transition-all duration-300',
                    STATUS_NODE_CLS[n.status],
                    dim ? 'opacity-30' : 'opacity-100',
                    lit && 'node-glow -translate-y-0.5'
                  )}
                >
                  <span className="truncate text-[12.5px] font-medium">{n.label}</span>
                  <span
                    className={cn(
                      'h-1.5 w-1.5 shrink-0 rounded-full',
                      n.status === 'completed' && 'bg-emerald-500',
                      n.status === 'in-progress' && 'bg-amber-500',
                      n.status === 'not-started' && 'bg-stone-400/60'
                    )}
                  />
                </button>
              )
            })}
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-4 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1.5"><GitBranch className="h-3 w-3" />{g.nodes.length} nodes · {g.edges.length} dependencies</span>
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm border border-emerald-500/50 bg-emerald-500/10" /> completed</span>
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm border border-amber-500/50 bg-amber-500/10" /> in progress</span>
          <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm border border-border bg-card" /> not started</span>
          <StatusBadge status="in-progress" />
          <span>hover to trace · click to research</span>
        </div>
      </motion.div>
    </div>
  )
}
