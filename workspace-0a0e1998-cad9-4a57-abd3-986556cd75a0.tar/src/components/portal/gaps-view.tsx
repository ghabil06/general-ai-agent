'use client'

import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { CheckCircle2, CircleDashed, ArrowUpRight, Layers3 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { COVERED, GAPS } from '@/lib/portal'
import { ProgressBar, SectionHeading, StatusBadge, DifficultyTag } from './atoms'

export function GapsView() {
  const { openTopic, savedTopics } = usePortal()
  const [hoveredGap, setHoveredGap] = useState<string | null>(null)

  const grouped = useMemo(() => {
    const map = new Map<string, typeof COVERED>()
    for (const c of COVERED) {
      const arr = map.get(c.category) ?? []
      arr.push(c)
      map.set(c.category, arr)
    }
    return [...map.entries()]
  }, [])

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="What I Know · What I'm Missing"
        title="The honest ledger"
        sub="Left: technologies already in production use. Right: the twelve research gaps the review identified — each is a living research card, not a checkbox."
      />

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        {/* ── Already Covered ── */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="mb-3 flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-600/10 text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-[15px] font-semibold tracking-tight">Already Covered</h3>
              <p className="text-xs text-muted-foreground">{COVERED.length} technologies in active use</p>
            </div>
          </div>
          <Card className="border-emerald-600/15 bg-gradient-to-b from-emerald-500/[0.04] to-transparent">
            <CardContent className="max-h-[560px] space-y-5 overflow-y-auto p-5 scrollbar-slim">
              {grouped.map(([category, items]) => (
                <div key={category}>
                  <div className="pb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">
                    {category}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {items.map((c) => (
                      <span
                        key={c.name}
                        className="group inline-flex items-center gap-1.5 rounded-lg border bg-card px-2.5 py-1.5 text-xs font-medium transition-all duration-200 hover:border-emerald-500/40 hover:shadow-sm"
                      >
                        <CheckCircle2 className="h-3 w-3 text-emerald-500/80" />
                        {c.name}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
              <p className="rounded-lg border bg-secondary/50 p-3 text-[11px] leading-relaxed text-muted-foreground">
                The review’s verdict: breadth here is real but uneven — application-level fluency in most, internals
                depth in few. The gaps on the right are chosen to add depth, not more frameworks.
              </p>
            </CardContent>
          </Card>
        </motion.section>

        {/* ── Research Gaps ── */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="mb-3 flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <CircleDashed className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-[15px] font-semibold tracking-tight">Research Gaps</h3>
              <p className="text-xs text-muted-foreground">{GAPS.length} priority areas · ordered by the review</p>
            </div>
          </div>
          <div className="max-h-[560px] space-y-2 overflow-y-auto pr-1 scrollbar-slim">
            {GAPS.map((g, i) => (
              <motion.button
                key={g.id}
                initial={{ opacity: 0, x: 14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 + i * 0.045, ease: [0.22, 1, 0.36, 1] }}
                onMouseEnter={() => setHoveredGap(g.id)}
                onMouseLeave={() => setHoveredGap(null)}
                onClick={() => openTopic(g.id, 'gap')}
                className={cn(
                  'group block w-full rounded-xl border bg-card p-4 text-left transition-all duration-300',
                  hoveredGap === g.id
                    ? 'border-primary/40 shadow-md shadow-primary/5 -translate-y-0.5'
                    : 'hover:border-primary/25'
                )}
              >
                <div className="flex items-start gap-3.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-amber-500/10 font-mono text-[13px] font-semibold text-amber-700 dark:text-amber-400">
                    {String(g.rank).padStart(2, '0')}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-[14px] font-semibold tracking-tight group-hover:text-primary">
                        {g.name}
                      </span>
                      <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/40 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" />
                    </div>
                    <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{g.tagline}</p>
                    <div className="mt-2.5 flex items-center gap-3">
                      <ProgressBar value={g.progress} className="max-w-32" barClassName="bg-amber-500" />
                      <span className="text-[11px] tabular-nums text-muted-foreground">{g.progress}%</span>
                      <StatusBadge status={g.status} className="ml-auto hidden sm:inline-flex" />
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                      <DifficultyTag level={g.difficulty} />
                      {savedTopics.includes(g.id) && (
                        <span className="inline-flex items-center gap-1 text-primary">
                          <Layers3 className="h-3 w-3" /> saved
                        </span>
                      )}
                      <span className="hidden md:inline">· {g.estimatedScope}</span>
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </motion.section>
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="quote-mark mx-auto mt-10 max-w-3xl rounded-xl border bg-card p-5 pl-8 text-center text-[13.5px] leading-relaxed text-muted-foreground"
      >
        The major issue is not simply adding more frameworks — it is building the foundational and production-engineering
        layer that connects the technologies together. Every gap above exists to serve that thesis.
      </motion.p>
    </div>
  )
}
