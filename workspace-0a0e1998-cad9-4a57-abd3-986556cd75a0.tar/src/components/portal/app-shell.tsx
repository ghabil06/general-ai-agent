'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import {
  LayoutDashboard,
  Map as MapIcon,
  Route,
  Microscope,
  FolderKanban,
  NotebookPen,
  Search,
  Bell,
  Moon,
  Sun,
  Sparkles,
  PanelLeftClose,
  PanelLeft,
  CircleDot,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'
import { cn } from '@/lib/utils'
import { usePortal, type ViewId } from '@/lib/store'
import { GAPS, STATS, type DomainId } from '@/lib/portal'
import { useTheme } from './theme'
import { GlobalSearch } from './global-search'

const NAV: { id: ViewId | 'copilot'; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Research', icon: LayoutDashboard },
  { id: 'knowledge-map', label: 'Knowledge Map', icon: MapIcon },
  { id: 'roadmap', label: 'Roadmap', icon: Route },
  { id: 'explorer', label: 'Technologies', icon: Microscope },
  { id: 'projects', label: 'Projects', icon: FolderKanban },
  { id: 'notes', label: 'Notes', icon: NotebookPen },
  { id: 'copilot', label: 'AI Copilot', icon: Sparkles },
]

interface SideItem {
  id: ViewId
  label: string
  domain?: DomainId
  icon?: typeof LayoutDashboard
}

const SIDEBAR: { group: string; items: SideItem[] }[] = [
  {
    group: 'Workspace',
    items: [
      { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
      { id: 'gaps', label: 'My Knowledge', icon: CircleDot },
      { id: 'gaps', label: 'Research Gaps', icon: CircleDot },
      { id: 'explorer', label: 'Topics', icon: Microscope },
      { id: 'graph', label: 'Technology Map', icon: MapIcon },
    ],
  },
  {
    group: 'Domains',
    items: [
      { id: 'knowledge-map', label: 'System Design', domain: 'system-design' },
      { id: 'knowledge-map', label: 'AI / ML', domain: 'ai-ml' },
      { id: 'knowledge-map', label: 'MLOps', domain: 'mlops' },
      { id: 'knowledge-map', label: 'Data Engineering', domain: 'data-engineering' },
    ],
  },
  {
    group: 'Output',
    items: [
      { id: 'projects', label: 'Projects', icon: FolderKanban },
      { id: 'notes', label: 'Notes', icon: NotebookPen },
      { id: 'notes', label: 'References', icon: NotebookPen },
    ],
  },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const { view, setView, copilotOpen, setCopilotOpen, setSearchOpen } = usePortal()
  const { theme, toggle } = useTheme()

  // ⌘K global search
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setSearchOpen(true)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [setSearchOpen])

  const handleNav = (id: ViewId | 'copilot') => {
    if (id === 'copilot') {
      setCopilotOpen(true)
    } else {
      setView(id)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const handleSide = (item: SideItem) => {
    setView(item.id)
    if (item.domain) usePortal.getState().setMapDomain(item.domain)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <TooltipProvider delayDuration={200}>
      <div className="min-h-screen flex flex-col bg-background">
        {/* ── Top navigation ── */}
        <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur-md supports-[backdrop-filter]:bg-background/70">
          <div className="flex h-14 items-center gap-3 px-4 md:px-6">
            <button
              className="flex items-center gap-2.5 pr-2"
              onClick={() => handleNav('dashboard')}
              aria-label="Argus home"
            >
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
                <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="3.2" />
                  <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1" strokeLinecap="round" />
                </svg>
              </span>
              <span className="hidden sm:block leading-tight text-left">
                <span className="block text-[13px] font-semibold tracking-tight">Argus</span>
                <span className="block text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                  Research Intelligence
                </span>
              </span>
            </button>

            <nav className="ml-2 hidden items-center gap-0.5 lg:flex" aria-label="Primary">
              {NAV.map((n) => {
                const Icon = n.icon
                const active = n.id !== 'copilot' && view === n.id
                return (
                  <button
                    key={n.id + n.label}
                    onClick={() => handleNav(n.id)}
                    className={cn(
                      'group relative flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[13px] font-medium transition-colors duration-300',
                      active
                        ? 'text-primary'
                        : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                    )}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {n.label}
                    {active && (
                      <span className="absolute inset-x-2.5 -bottom-[9px] h-0.5 rounded-full bg-primary" />
                    )}
                  </button>
                )
              })}
            </nav>

            <div className="ml-auto flex items-center gap-1.5">
              <button
                onClick={() => setSearchOpen(true)}
                className="hidden md:flex h-8.5 w-56 items-center gap-2 rounded-md border bg-secondary/60 px-2.5 text-[13px] text-muted-foreground transition-colors duration-300 hover:border-primary/40 hover:text-foreground"
              >
                <Search className="h-3.5 w-3.5" />
                <span className="flex-1 text-left truncate">Search topics…</span>
                <kbd className="rounded border bg-background px-1 font-mono text-[10px]">⌘K</kbd>
              </button>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9 md:hidden" onClick={() => setSearchOpen(true)} aria-label="Search">
                    <Search className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Search · ⌘K</TooltipContent>
              </Tooltip>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative h-8.5 w-8.5" aria-label="Notifications">
                    <Bell className="h-4 w-4" />
                    <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-primary" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-72">
                  <DropdownMenuLabel className="text-xs text-muted-foreground">
                    Research notifications
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="flex-col items-start gap-0.5 py-2.5">
                    <span className="text-[13px] font-medium">Kafka project unblocked</span>
                    <span className="text-xs text-muted-foreground">Consumer-group drill ready — priority #07 in progress</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex-col items-start gap-0.5 py-2.5">
                    <span className="text-[13px] font-medium">Roadmap review due</span>
                    <span className="text-xs text-muted-foreground">Rank {GAPS[0].rank} — {GAPS[0].name} weekly check-in</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex-col items-start gap-0.5 py-2.5">
                    <span className="text-[13px] font-medium">RAG eval regression</span>
                    <span className="text-xs text-muted-foreground">Golden-set score dipped 2.4% — chunking A/B suggested</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8.5 w-8.5" onClick={toggle} aria-label="Toggle research mode">
                    {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Dark research mode</TooltipContent>
              </Tooltip>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="ml-0.5 rounded-full outline-ring" aria-label="Profile">
                    <Avatar className="h-7.5 w-7.5 border">
                      <AvatarFallback className="bg-primary/10 text-primary text-[11px] font-semibold">
                        RS
                      </AvatarFallback>
                    </Avatar>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="text-[13px] font-medium">Researcher</div>
                    <div className="text-xs font-normal text-muted-foreground">
                      {STATS.researchHours}h logged · {STATS.gapsTotal} gaps tracked
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => handleNav('progress')}>Progress dashboard</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNav('notes')}>Research notes</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNav('copilot')}>Open AI Copilot</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => router.refresh()}>Refresh workspace</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* mobile nav row */}
          <nav className="flex items-center gap-1 overflow-x-auto border-t px-3 py-1.5 scrollbar-slim lg:hidden" aria-label="Primary mobile">
            {NAV.map((n) => {
              const Icon = n.icon
              const active = n.id !== 'copilot' && view === n.id
              return (
                <button
                  key={'m-' + n.id + n.label}
                  onClick={() => handleNav(n.id)}
                  className={cn(
                    'flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors duration-300',
                    active ? 'bg-primary/10 text-primary' : 'text-muted-foreground'
                  )}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {n.label}
                </button>
              )
            })}
          </nav>
        </header>

        <div className="flex flex-1">
          {/* ── Sidebar ── */}
          <aside className="sticky top-14 hidden h-[calc(100vh-3.5rem)] w-60 shrink-0 flex-col border-r bg-sidebar md:flex">
            <SideToggle />
            <div className="flex-1 overflow-y-auto px-3 py-3 scrollbar-slim">
              {SIDEBAR.map((g) => (
                <div key={g.group} className="mb-5">
                  <div className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">
                    {g.group}
                  </div>
                  <div className="space-y-0.5">
                    {g.items.map((it, idx) => {
                      const Icon = it.icon
                      const active = it.domain
                        ? view === it.id && usePortal.getState().mapDomain === it.domain
                        : view === it.id && it.label !== 'References'
                      return (
                        <button
                          key={it.label + idx}
                          onClick={() => handleSide(it)}
                          className={cn(
                            'flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-[13px] transition-colors duration-300',
                            active
                              ? 'bg-sidebar-accent font-medium text-sidebar-accent-foreground'
                              : 'text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground'
                          )}
                        >
                          {Icon ? (
                            <Icon className="h-3.5 w-3.5 shrink-0" />
                          ) : (
                            <span className="grid h-3.5 w-3.5 shrink-0 place-items-center">
                              <span className={cn('h-1.5 w-1.5 rounded-full', active ? 'bg-primary' : 'bg-current opacity-30')} />
                            </span>
                          )}
                          {it.label}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t p-3">
              <button
                onClick={() => setCopilotOpen(true)}
                className="group flex w-full items-center gap-2.5 rounded-lg border bg-card p-3 text-left transition-all duration-300 hover:border-primary/40 hover:shadow-sm"
              >
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-105">
                  <Sparkles className="h-4 w-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[13px] font-medium leading-4">Research Copilot</span>
                  <span className="block truncate text-[11px] text-muted-foreground">Ask · connect · plan</span>
                </span>
              </button>
            </div>
          </aside>

          {/* ── Main ── */}
          <main className="flex min-w-0 flex-1 flex-col">{children}</main>
        </div>

        {/* mobile copilot fab */}
        <button
          onClick={() => setCopilotOpen(!copilotOpen)}
          className="fixed bottom-5 right-5 z-40 grid h-12 w-12 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/25 transition-transform duration-300 hover:scale-105 md:hidden"
          aria-label="Toggle AI Copilot"
        >
          <Sparkles className="h-5 w-5" />
        </button>

        <GlobalSearch />
      </div>
    </TooltipProvider>
  )
}

function SideToggle() {
  return (
    <div className="flex items-center justify-between border-b px-4 py-2.5">
      <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">
        Navigator
      </span>
      <PanelLeftClose className="h-3.5 w-3.5 text-muted-foreground/50" />
    </div>
  )
}

export { PanelLeft }
