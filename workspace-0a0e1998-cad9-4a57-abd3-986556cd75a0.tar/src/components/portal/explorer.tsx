'use client'

import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Search, SlidersHorizontal, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'
import { usePortal } from '@/lib/store'
import { DOMAINS, searchPortal, SEARCH_INDEX } from '@/lib/portal'
import { StatusBadge, DifficultyTag, SectionHeading } from './atoms'
import type { Difficulty } from '@/lib/portal/types'

type DomainFilter = string
type StatusFilter = 'all' | 'completed' | 'in-progress' | 'not-started'
type KindFilter = 'all' | 'Fundamentals' | 'Practical' | 'Production'
type TypeFilter = 'all' | 'topic' | 'gap' | 'comparison' | 'project'

export function ExplorerView() {
  const { explorerQuery, setExplorerQuery, openTopic, setView } = usePortal()
  const [domain, setDomain] = useState<DomainFilter>('all')
  const [difficulty, setDifficulty] = useState<'all' | Difficulty>('all')
  const [status, setStatus] = useState<StatusFilter>('all')
  const [kind, setKind] = useState<KindFilter>('all')
  const [type, setType] = useState<TypeFilter>('all')

  const results = useMemo(() => {
    const base = explorerQuery.trim() ? searchPortal(explorerQuery) : SEARCH_INDEX
    return base.filter((e) => {
      if (type !== 'all' && e.kind !== type) return false
      if (domain !== 'all' && e.domainId !== domain && e.domain !== 'Comparison' && e.domain !== 'Project Lab') return false
      if (difficulty !== 'all' && e.difficulty !== difficulty) return false
      if (status !== 'all' && e.status !== status && e.status !== 'reference') return false
      if (kind !== 'all' && e.kindLabel !== kind) return false
      return true
    })
  }, [explorerQuery, domain, difficulty, status, kind, type])

  const activeFilters = [domain !== 'all', difficulty !== 'all', status !== 'all', kind !== 'all', type !== 'all'].filter(Boolean).length

  const reset = () => {
    setDomain('all')
    setDifficulty('all')
    setStatus('all')
    setKind('all')
    setType('all')
  }

  const open = (id: string, kind: 'topic' | 'gap') => openTopic(id, kind)

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Research Topic Explorer"
        title="Search the corpus"
        sub="Topics, gaps, comparisons, and lab projects in one searchable index — filter by domain, difficulty, research status, and kind."
      />

      {/* Search bar */}
      <div className="mt-6 rounded-xl border bg-card p-3 shadow-sm">
        <div className="flex items-center gap-2.5">
          <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
          <Input
            value={explorerQuery}
            onChange={(e) => setExplorerQuery(e.target.value)}
            placeholder="Search a technology, concept, architecture, or research topic…"
            className="h-9 border-0 bg-transparent px-0 shadow-none focus-visible:ring-0"
            aria-label="Search topics"
          />
          {explorerQuery && (
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => setExplorerQuery('')} aria-label="Clear search">
              <X className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
        <div className="mt-2.5 flex flex-wrap items-center gap-1.5 border-t pt-2.5">
          <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <SlidersHorizontal className="h-3 w-3" /> Filters
            {activeFilters > 0 && <span className="rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground">{activeFilters}</span>}
          </span>

          <Select value={domain} onValueChange={setDomain}>
            <SelectTrigger className="h-7 w-auto gap-1 rounded-full border-border/70 bg-secondary/50 px-3 text-xs" aria-label="Domain filter">
              <SelectValue placeholder="Domain" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All domains</SelectItem>
              {DOMAINS.map((d) => (
                <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={difficulty} onValueChange={(v) => setDifficulty(v as never)}>
            <SelectTrigger className="h-7 w-auto gap-1 rounded-full border-border/70 bg-secondary/50 px-3 text-xs" aria-label="Difficulty filter">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any difficulty</SelectItem>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>

          <Select value={status} onValueChange={(v) => setStatus(v as never)}>
            <SelectTrigger className="h-7 w-auto gap-1 rounded-full border-border/70 bg-secondary/50 px-3 text-xs" aria-label="Status filter">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="not-started">Not Started</SelectItem>
            </SelectContent>
          </Select>

          <Select value={kind} onValueChange={(v) => setKind(v as never)}>
            <SelectTrigger className="h-7 w-auto gap-1 rounded-full border-border/70 bg-secondary/50 px-3 text-xs" aria-label="Kind filter">
              <SelectValue placeholder="Kind" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Fundamentals / Practical / Production</SelectItem>
              <SelectItem value="Fundamentals">Fundamentals</SelectItem>
              <SelectItem value="Practical">Practical</SelectItem>
              <SelectItem value="Production">Production</SelectItem>
            </SelectContent>
          </Select>

          <Select value={type} onValueChange={(v) => setType(v as never)}>
            <SelectTrigger className="h-7 w-auto gap-1 rounded-full border-border/70 bg-secondary/50 px-3 text-xs" aria-label="Type filter">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="topic">Topics</SelectItem>
              <SelectItem value="gap">Research gaps</SelectItem>
              <SelectItem value="comparison">Comparisons</SelectItem>
              <SelectItem value="project">Projects</SelectItem>
            </SelectContent>
          </Select>

          {activeFilters > 0 && (
            <Button variant="ghost" size="sm" className="h-7 gap-1 px-2 text-xs" onClick={reset}>
              Reset
            </Button>
          )}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
        <span>
          <span className="font-semibold tabular-nums text-foreground">{results.length}</span> result{results.length === 1 ? '' : 's'}
          {explorerQuery && <> for “{explorerQuery}”</>}
        </span>
        <span className="hidden sm:block">click any row to open the research workspace</span>
      </div>

      {/* Results */}
      <div className="mt-3 space-y-2 pb-4">
        <AnimatePresence mode="popLayout">
          {results.map((e, i) => (
            <motion.button
              layout
              key={e.kind + e.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3, delay: Math.min(i * 0.02, 0.25), ease: [0.22, 1, 0.36, 1] }}
              onClick={() => {
                if (e.kind === 'comparison') setView('comparison')
                else if (e.kind === 'project') setView('projects')
                else open(e.id, e.kind as 'topic' | 'gap')
              }}
              className="group flex w-full flex-col gap-2 rounded-xl border bg-card p-4 text-left transition-all duration-300 hover:border-primary/35 hover:shadow-sm sm:flex-row sm:items-center"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[14px] font-semibold tracking-tight group-hover:text-primary">{e.name}</span>
                  <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                    {e.kindLabel}
                  </span>
                  <span className="text-[11px] text-muted-foreground">· {e.domain}</span>
                </div>
                <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{e.summary}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {e.technologies.slice(0, 5).map((t) => (
                    <span key={t} className="rounded border bg-secondary/40 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-3 sm:flex-col sm:items-end sm:gap-1.5">
                {e.status !== 'reference' ? <StatusBadge status={e.status as never} /> : <span className="rounded-full border bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground">Reference</span>}
                <DifficultyTag level={e.difficulty} />
              </div>
            </motion.button>
          ))}
        </AnimatePresence>
        {results.length === 0 && (
          <div className={cn('rounded-xl border border-dashed p-10 text-center text-sm text-muted-foreground')}>
            Nothing matches those filters. <button className="text-primary underline-offset-2 hover:underline" onClick={reset}>Reset filters</button> or try “Kafka”, “OAuth”, “CAP”.
          </div>
        )}
      </div>
    </div>
  )
}
