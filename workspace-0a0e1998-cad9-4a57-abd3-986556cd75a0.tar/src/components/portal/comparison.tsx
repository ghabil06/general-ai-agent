'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Scale, Quote } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import { COMPARISONS } from '@/lib/portal'
import { SectionHeading } from './atoms'

export function ComparisonView() {
  const [activeId, setActiveId] = useState(COMPARISONS[0].id)
  const active = COMPARISONS.find((c) => c.id === activeId)!

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
      <SectionHeading
        eyebrow="Technology Comparison"
        title="Compare before you commit"
        sub="Factual, research-oriented side-by-side analysis across nine engineering dimensions — drawn from the technologies named in the review."
      />

      {/* Selector chips */}
      <div className="mt-6 flex flex-wrap gap-1.5">
        {COMPARISONS.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveId(c.id)}
            className={cn(
              'rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all duration-300',
              activeId === c.id
                ? 'border-primary/50 bg-primary/10 text-primary'
                : 'text-muted-foreground hover:border-primary/30 hover:text-foreground'
            )}
          >
            {c.title}
          </button>
        ))}
      </div>

      <motion.div
        key={active.id}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        className="mt-5"
      >
        <Card className="overflow-hidden">
          <div className="border-b bg-secondary/40 px-5 py-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-[16px] font-semibold tracking-tight">{active.title}</h3>
                <p className="text-xs text-muted-foreground">{active.subtitle}</p>
              </div>
              <div className="flex items-center gap-1.5">
                <Scale className="h-3.5 w-3.5 text-primary" />
                <span className="text-[11px] font-medium text-muted-foreground">{active.rows.length} dimensions</span>
              </div>
            </div>
          </div>

          <CardContent className="p-0">
            {/* Header row */}
            <div className="grid" style={{ gridTemplateColumns: `160px repeat(${active.options.length}, minmax(0,1fr))` }}>
              <div className="border-b bg-card px-4 py-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                Dimension
              </div>
              {active.options.map((o, i) => (
                <div
                  key={o}
                  className={cn(
                    'border-b px-4 py-3 text-[13px] font-semibold',
                    i === 0 ? 'border-l' : '',
                    'bg-primary/[0.04]'
                  )}
                >
                  {o}
                </div>
              ))}
              {active.rows.map((row) => (
                <Row key={row.dimension} dimension={row.dimension} values={row.values} cols={active.options.length} />
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="quote-mark mt-4 rounded-xl border bg-card p-5 pl-9">
          <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
            <Quote className="h-3 w-3" /> Research verdict
          </div>
          <p className="text-[13.5px] leading-relaxed text-muted-foreground">{active.verdict}</p>
        </div>
      </motion.div>
    </div>
  )
}

function Row({ dimension, values, cols }: { dimension: string; values: string[]; cols: number }) {
  return (
    <>
      <div className="border-b bg-card px-4 py-3 text-xs font-medium text-muted-foreground">{dimension}</div>
      {values.slice(0, cols).map((v, i) => (
        <div
          key={i}
          className={cn(
            'border-b px-4 py-3 text-[12.5px] leading-relaxed text-muted-foreground transition-colors duration-200 hover:bg-secondary/40',
            i === 0 ? 'border-l' : ''
          )}
        >
          {v}
        </div>
      ))}
    </>
  )
}
