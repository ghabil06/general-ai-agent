'use client'

import { cn } from '@/lib/utils'

/**
 * Minimal markdown renderer for copilot replies:
 * supports **bold**, *italic*, `code`, - bullets, and line breaks.
 */
export function MarkdownLite({ text, className }: { text: string; className?: string }) {
  const blocks = text.split(/\n{2,}/)

  const renderInline = (s: string): React.ReactNode[] => {
    const parts: React.ReactNode[] = []
    const regex = /(\*\*[^*]+\*\*|\*[^*\n]+\*|`[^`]+`)/g
    let last = 0
    let m: RegExpExecArray | null
    while ((m = regex.exec(s))) {
      if (m.index > last) parts.push(s.slice(last, m.index))
      const tok = m[0]
      if (tok.startsWith('**')) {
        parts.push(
          <strong key={m.index} className="font-semibold text-foreground">
            {tok.slice(2, -2)}
          </strong>
        )
      } else if (tok.startsWith('`')) {
        parts.push(
          <code key={m.index} className="rounded bg-secondary px-1 py-0.5 font-mono text-[0.85em]">
            {tok.slice(1, -1)}
          </code>
        )
      } else {
        parts.push(<em key={m.index}>{tok.slice(1, -1)}</em>)
      }
      last = m.index + tok.length
    }
    if (last < s.length) parts.push(s.slice(last))
    return parts
  }

  return (
    <div className={cn('space-y-2', className)}>
      {blocks.map((block, i) => {
        const lines = block.split('\n')
        const isList = lines.every((l) => /^\s*[-•]\s+/.test(l)) && lines.length > 0
        if (isList) {
          return (
            <ul key={i} className="space-y-1.5">
              {lines.map((l, j) => (
                <li key={j} className="flex items-start gap-2">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-primary/70" />
                  <span>{renderInline(l.replace(/^\s*[-•]\s+/, ''))}</span>
                </li>
              ))}
            </ul>
          )
        }
        const isNumbered = lines.every((l) => /^\s*\d+\.\s+/.test(l)) && lines.length > 0
        if (isNumbered) {
          return (
            <ol key={i} className="space-y-1.5">
              {lines.map((l, j) => (
                <li key={j} className="flex items-start gap-2">
                  <span className="mt-0.5 shrink-0 font-mono text-[10px] font-semibold text-primary">
                    {String(j + 1).padStart(2, '0')}
                  </span>
                  <span>{renderInline(l.replace(/^\s*\d+\.\s+/, ''))}</span>
                </li>
              ))}
            </ol>
          )
        }
        return (
          <p key={i}>
            {lines.map((l, j) => (
              <span key={j}>
                {renderInline(l)}
                {j < lines.length - 1 && <br />}
              </span>
            ))}
          </p>
        )
      })}
    </div>
  )
}
